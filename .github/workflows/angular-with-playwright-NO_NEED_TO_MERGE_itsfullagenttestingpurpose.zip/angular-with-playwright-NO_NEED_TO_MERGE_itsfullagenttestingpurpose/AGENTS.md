# Playwright E2E — Agent Guide

Angular 21 app with a Playwright E2E suite under `e2e/`. The suite is an **external black-box
consumer** of the app: nothing in `e2e/` may know how `src/` is implemented.

This file is the index, not the ruleset. Task-specific guidance lives in **`.agents/skills/`** —
load the one that matches what you are doing. (Claude Code reaches the same files through
`.claude/skills/` symlinks.)

> **This repo is a sandbox.** The app in `src/` is a skeleton used to exercise the architecture.
> The deliverable is `.agents/skills/` + `.agents/commands/`, which travel to the real PnL/Risk
> repo. Files marked *reference implementation* compile but are not exercised by any spec here.

---

## Skill index

| When you are… | Skill |
| :-- | :-- |
| Orienting, deciding where code belongs, auditing or reviewing the suite | `playwright-architecture` |
| Designing a page, component or cockpit-widget object | `playwright-page-component-objects` |
| Adding tests for a new feature, page, modal or flow | `playwright-add-feature-test` |
| Choosing a locator, or writing/fixing an assertion | `playwright-locators-and-assertions` |
| Adding a fixture, wiring DI, touching auth or `storageState` | `playwright-fixtures-and-auth` |
| Mocking ClickHouse queries, seeding data, Zod contracts, fault injection | `playwright-data-and-api-mocking` |
| Writing an axe (`@a11y`) or screenshot (`@visual`) spec | `playwright-a11y-and-visual` |
| Tags, sharding, reporters, CI workflows, the insights dashboard | `playwright-ci-and-telemetry` |
| Debugging a failing or flaky spec | `playwright-debug-and-flake` |
| Generating a test from a scenario, journey or bug repro | `playwright-generate-test` |
| Maintaining the `ng-add` schematic (sandbox-only) | `playwright-blueprint-schematic` |

Commands in **`.agents/commands/`**: `/e2e-scaffold`, `/e2e-validate`, `/e2e-debug`,
`/e2e-insights`, `/e2e-audit-a11y`.

---

## Non-negotiables

1. **No `src/` imports inside `e2e/`.** Enforced by `no-restricted-imports` in `eslint.config.mjs`;
   do not weaken it.
2. **Path aliases only** — `@components/*`, `@pages/*`, `@fixtures/*`, `@helpers/*`, `@global/*`,
   `@specs/*` (declared in `e2e/tsconfig.json`). Never `../../components/…`.
3. **Specs import `{ test, expect }` from `@fixtures/index`**, never from `@playwright/test`. Page
   objects, component objects, fixtures and helpers may; specs are the layer that must not.
4. **Named exports only.** No default exports anywhere in `e2e/`.
5. **Composition, never inheritance.** No `BasePage`. A specialized dialog composes
   `ModalComponent`; a widget composes `WidgetContainerComponent` and adds only its own controls.
6. **A spec never sees a raw selector.** Spec → page object → component object → selectors.
7. **Pages own their embedded widgets; component fixtures hold only global chrome** (toast, loader,
   header, generic modal). Registering a page-embedded widget as a fixture hands the spec a second,
   unopened instance.
8. **Role-first locators** — `getByRole` → `getByLabel` → `getByPlaceholder` → `getByText` →
   `[data-test="…"]` → CSS/XPath last. `getByTestId()` does **not** work here: `testIdAttribute` is
   unset, so it looks for `data-testid` while the app uses `data-test`.
9. **Zero sleeps** in specs, pages and components. No `waitForTimeout`, no manual `setTimeout`. Use
   auto-waiting assertions. (A `setTimeout` inside a *route handler* delays a mocked response, not
   the test — that one is legitimate.)
10. **Wrap every public page/component action in `test.step('…')`** — it is what makes the HTML and
    Allure reports readable.
11. **Tag every test** in the options object: `@smoke @regression @ui @api @contract @resilience
    @auth @setup @a11y @visual`. Untagged tests are invisible to every filtered job.
12. **Guard vs business assertions.** Guards (visibility, action post-conditions) live inside page
    and component objects to prevent flakiness. Business assertions are parameterized
    (`expectMetric(expected)`) or asserted in the spec. Never `expect.soft` inside a POM.
13. **Never commit `e2e/auth/*.json`** (gitignored session state) and never hardcode credentials —
    they come from `e2e/fixtures/creds.ts`, fed by `E2E_*` env vars. Unauthenticated specs opt out
    explicitly: `test.use({ storageState: { cookies: [], origins: [] } })`.
14. **Every seeded entity is torn down** in the fixture's post-`use` phase, disposed in a `finally`.

---

## Daily workflow

1. **Scaffold** — `npm run e2e:scaffold <featureName>` (or `/e2e-scaffold`). Add `--panel` for a
   non-dialog widget.
2. **Build** — component object → page object → route key in `e2e/pages/routes.ts` → fixture in
   `e2e/fixtures/pageFixtures.ts` → spec.
3. **Validate** — `npm run e2e:validate` (eslint + tsc + `--list`). No dev server needed; catches
   nearly everything structural.
4. **Run** — `npx playwright test e2e/specs/<feature>.spec.ts`, or `npm run e2e:smoke`.
5. **Debug** — `/e2e-debug <spec>`, or `npx playwright test <spec> --ui`.
6. **Report** — `npm run insights:all && npm run e2e:report`.

## Reference prompts

> **New cockpit widget test.** "Add E2E coverage for the VaR breakdown widget on `/cockpit`. Build
> the component object composing `WidgetContainerComponent`, own it on `CockpitPage`, and write a
> `@smoke` spec." → `playwright-add-feature-test`, then `playwright-page-component-objects`.

> **AG-Grid blotter.** "Test the PnL blotter: sort `pnl_usd` descending, filter desk to 'Equity
> Derivatives', expand the 'EMEA' group, and assert the desk total is 4,520,000." →
> `playwright-locators-and-assertions`, driving `AgGridComponent`.

> **Highcharts risk chart.** "Verify the VaR trend chart renders 12 points, toggle the 'Historical
> Simulation' series off via the legend, then hover Q1 and assert the tooltip shows VaR 99%." →
> `playwright-locators-and-assertions`, driving `HighchartsComponent`.

> **ClickHouse mocking + contract.** "Intercept `POST **/api/analytics/pnl**` with a 5,000-row
> aggregate, validate it against `ClickHousePnLResponseSchema`, assert the loader clears and the
> grid populates." → `playwright-data-and-api-mocking`.

> **Bug repro → test.** "Reproduce this bug as a spec: applying two groupings then resetting leaves
> one chip behind." → `playwright-generate-test`.

> **Flaky spec.** "`view-groupings.spec.ts` passes locally and fails on shard 3." → `/e2e-debug`,
> then `playwright-debug-and-flake`.

---

## Validation gate — before every push

```bash
npm run e2e:validate
# = npx eslint e2e                        decoupling + lint
#   npx tsc -p e2e/tsconfig.json --noEmit types + alias resolution (NOT tsconfig.spec.json)
#   npx playwright test --list            loads the whole fixture/POM graph; proves wiring
```

Then run the affected specs. If you added an **architecture** file under `e2e/`, `scripts/` or
`playwright.config.ts`, also add it to `filesToSync` in `schematics/scripts/sync-and-build.ts` and
run `npm run build:schematics` — see `playwright-blueprint-schematic`.
