---
name: playwright-page-component-objects
description: How to design Page Objects, Component Objects and cockpit Widget Objects in this Playwright suite — composition over inheritance, generic shell reuse, rootLocator scoping, page-owns-its-widgets vs component-fixture placement, guard vs business assertions, method taxonomy, naming, and anti-patterns. Use when creating or restructuring any page or component object.
---

# Page, Component & Widget Objects

This skill owns **object structure**: `test.step` wrapping, composition, and widget ownership.
Selector choice is owned by `playwright-locators-and-assertions`; fixture registration by
`playwright-fixtures-and-auth`.

Three kinds of object, three jobs:

| Object | Scope | Knows about |
| :-- | :-- | :-- |
| **Generic shell** — `ModalComponent`, `WidgetContainerComponent`, `PrimeDialogComponent` | A UI *archetype* — container chrome | root, title, close/header controls, open/closed state. Nothing feature-specific. |
| **Component / widget object** — `AgGridComponent`, `HighchartsComponent`, `GroupingsModalComponent`, `KpiCardWidgetComponent`, `PrimeDropdownComponent`, `PrimeTableComponent`, `PrimeMultiSelectComponent` | One reusable widget, instance-scoped | its own selectors, interactions and guard assertions. **Never** routes, URLs or other screens. |
| **Page object** — `CockpitPage`, `ViewPage` | One route/screen | navigation, screen-unique locators, **ownership** of the widgets on that screen. **Never** re-declares a widget's selectors, never hosts multi-page flows. |

## Naming & file conventions

| Thing | Convention | Example |
| :-- | :-- | :-- |
| Page file / class | `camelCasePage.ts` / `PascalCasePage` | `cockpitPage.ts` → `CockpitPage` |
| Component file / class | `camelCase.component.ts` / `PascalCaseComponent` | `agGrid.component.ts` → `AgGridComponent` |
| Spec file | `kebab-case.spec.ts` | `view-groupings.spec.ts` |
| Export style | named, always | `export class CockpitPage` |

## Core rules

1. **Accept an optional `rootLocator?: Locator`.** It lets one class bind to any instance on screen —
   two grids in two cockpit slots, the same `AgGridComponent`. Default to a page-wide locator when
   omitted. The exception is a component that is *only ever* one of many (`WidgetContainerComponent`),
   where the root is required because no page-wide default is meaningful.
2. **Every child locator hangs off `this.root`**, never off `page`. The one exception is a genuine
   body-level portal — an AG-Grid filter popup, a global dialog — which must be located from `page`
   with a comment saying why.
3. **Compose shells; never inherit.** A specialized dialog composes `ModalComponent` for chrome. A
   table widget *has* a grid; it is not *a kind of* grid. **There is no `BasePage` and never will be.**
4. **Wrap every public action and verification in `test.step('Human readable label', …)`.** This is
   what makes the HTML and Allure reports readable.
5. **Getters return `Locator` synchronously**, never `Promise<Locator>`. Locators are lazy; building
   one needs no `await`.

## Composition in practice

`GroupingsModalComponent` (`e2e/components/groupingsModal.component.ts`) is the reference: it builds
a scoped root, hands it to a composed `ModalComponent`, re-exposes the chrome, and then declares only
its own controls.

```ts
export class GroupingsModalComponent {
  readonly modal: ModalComponent;
  readonly root: Locator;
  readonly applyButton: Locator;

  constructor(page: Page, rootLocator?: Locator) {
    const root = rootLocator ?? page.getByRole('dialog', { name: /grouping/i })
      .or(page.locator('[data-test="groupings-modal"]'));

    this.modal = new ModalComponent(page, root);   // chrome lives in exactly one place
    this.root = this.modal.root;

    this.applyButton = this.root.getByRole('button', { name: /apply|appliquer/i })
      .or(this.root.locator('[data-test="apply-groupings"]'));
  }

  async apply(): Promise<void> {
    await test.step('Apply groupings and verify the modal closes', async () => {
      await this.applyButton.click();
      await this.modal.expectClosed();      // guard assertion — the action's post-condition
    });
  }
}
```

Cockpit widgets follow the identical shape one level up: `TableWidgetComponent` composes
`WidgetContainerComponent` for the header chrome and an `AgGridComponent` scoped to `container.body`.

## Ownership: page-owned widget vs component fixture

One question: **can this widget appear on any screen, or does one screen host it?**

```
Global chrome — toast, loader, header, generic modal shell
    → register in e2e/fixtures/componentFixtures.ts, inject into the spec
Screen-specific widget — AG-Grid table, chart, cockpit widget, groupings modal
    → instantiate in that page's constructor; reach it as cockpitPage.pnlTableWidget
```

Registering a screen-embedded widget as a fixture hands the spec a **second instance** that is not
the one the page rendered and opened. Never do both.

## Guard vs business assertions

| Kind | Where | Example |
| :-- | :-- | :-- |
| **Guard** — synchronization, action post-conditions | Inside the page/component object | `await expect(this.root).toBeVisible()`; asserting a modal closed after `apply()` |
| **Business** — the thing the test is actually claiming | In the spec, or a parameterized `expect*` method | `expect(await grid.getFinancialCellValue('1042','pnl_usd')).toBe(4520000)` |

Guards prevent flakiness, so they belong in the object. Business assertions belong to the test, so
either assert in the spec or pass the expectation in (`expectMetric(expected)`) — never hardcode an
expected business value inside a POM. **Never use `expect.soft` inside a POM**; objects fail fast.

## Method taxonomy

| Prefix | Returns | Rule |
| :-- | :-- | :-- |
| `visit` / `goTo` | `Promise<void>` | Page objects only; path via `Routes`, never a literal |
| `open` / `close` | `Promise<void>` | Ends by asserting the resulting state |
| verbs — `sort`, `filter`, `expand`, `configure` | `Promise<void>` | One user intent per method |
| `expect*` | `Promise<void>` | Web-first assertion on this object's state |
| `verify*` | `Promise<void>` | Composed assertion that also interacts (e.g. hover then assert tooltip) |
| `get*` | `Locator` — **not** `Promise<Locator>` | Lazy locator construction |

## Anti-patterns

| ❌ Don't | ✅ Do |
| :-- | :-- |
| `new AgGridComponent(page)` inside a spec | `cockpitPage.pnlTableWidget.grid` |
| A `BasePage` others extend | Compose a standalone shell component |
| `page.locator('.ag-cell')` inside `AgGridComponent` | `this.root.locator('.ag-cell')` |
| `async getCell(): Promise<Locator>` | `getCell(): Locator` |
| Hardcode `'/cockpit'` in the page object | `this.routes.goToCockpit()` |
| Re-declare a modal's close button in a specialized dialog | Compose `ModalComponent` |
| Register `groupingsModal` as a component fixture | Own it on `ViewPage` |

## Canonical files to copy from

| Need | File |
| :-- | :-- |
| Generic modal shell | `e2e/components/modal.component.ts` |
| Composed dialog | `e2e/components/groupingsModal.component.ts` |
| Global chrome | `e2e/components/header.component.ts`, `toast.component.ts`, `loader.component.ts` |
| Virtualized data grid | `e2e/components/agGrid.component.ts` |
| SVG chart | `e2e/components/highcharts.component.ts` |
| Widget shell + settings dialog | `e2e/components/widgetContainer.component.ts` |
| Specialized widgets | `e2e/components/cockpitWidgets.component.ts` |
| Page that owns widgets | `e2e/pages/cockpitPage.ts` |
| Page with one embedded dialog | `e2e/pages/viewPage.ts` |
| URL registry | `e2e/pages/routes.ts` |

> The grid, chart, widget and cockpit files are **reference implementations**: they compile and
> type-check, but this sandbox app renders no AG-Grid, Highcharts or cockpit, so their selectors have
> never run against a live DOM. Verify and adjust them against the real app on first use.
