---
name: playwright-data-and-api-mocking
description: Test data, ClickHouse analytical query mocking, and network control for this Playwright suite — Zod 4 contract schemas (fail-fast parse vs telemetry safeParse), ClickHouse columnar JSON response factories, synthetic financial data generation, APIClient context ownership, route mocking & interception, latency/fault injection, W3C traceparent headers, and file export validation.
---

# Test Data, API Contracts & Mocking

## Zod runtime contracts

Schemas live in `e2e/fixtures/dataFactoryFixture.ts` (`UserSchema`, `AuthResponseSchema`, `ClickHousePnLResponseSchema`, `ErrorResponseSchema`) and are the shared truth for both sides:

| Where | Call | Why |
| :-- | :-- | :-- |
| E2E specs & `APIClient` | `schema.parse(json)` | fail fast — a drifted contract must break the test |
| Angular `apiContractInterceptor` (`src/app/core/interceptors/`) | `schema.safeParse(body)` | observe drift, log a warning, never crash the UI |

The project is on **Zod 4** — use the top-level string formats (`z.uuid()`, `z.email()`), not the
Zod 3 chained form (`z.string().uuid()`).

Register an app-side contract so the interceptor watches an endpoint:

```ts
registerApiContract('/api/auth/me', AuthResponseSchema);
registerApiContract('/api/analytics/pnl', ClickHousePnLResponseSchema);
```

---

## ClickHouse Analytical Schemas & Synthetic Data Factory

ClickHouse provides fast columnar query evaluation for trading cockpits. Responses return metadata headers, columnar records, row counts, and query execution statistics:

```ts
import { z } from 'zod';

export const ClickHouseMetaFieldSchema = z.object({
  name: z.string(),
  type: z.string(),
});

export const PnLRecordSchema = z.object({
  trade_id: z.string(),
  book: z.string(),
  desk: z.string(),
  currency: z.string(),
  pnl_usd: z.number(),
  var_95: z.number(),
  delta_usd: z.number(),
  trade_count: z.number().int().nonnegative(),
  cob_date: z.string(),
});
export type PnLRecord = z.infer<typeof PnLRecordSchema>;

export const ClickHousePnLResponseSchema = z.object({
  meta: z.array(ClickHouseMetaFieldSchema),
  data: z.array(PnLRecordSchema),
  rows: z.number().int().nonnegative(),
  statistics: z
    .object({
      elapsed: z.number(),
      rows_read: z.number(),
      bytes_read: z.number(),
    })
    .optional(),
});
export type ClickHousePnLResponse = z.infer<typeof ClickHousePnLResponseSchema>;
```

### Synthetic Data Generator

```ts
export function generatePnLRecords(count = 5, overrides: Partial<PnLRecord> = {}): PnLRecord[] {
  const desks = ['Global Equities', 'Macro Rates', 'Credit Trading', 'Commodities'];
  const books = ['EQ_VOL_1', 'RATES_STIR_2', 'CREDIT_HY_1', 'COMM_OIL_3'];
  const currencies = ['USD', 'EUR', 'GBP', 'JPY'];

  return Array.from({ length: count }, (_, idx) => ({
    trade_id: `TRD-${1000 + idx}`,
    book: books[idx % books.length],
    desk: desks[idx % desks.length],
    currency: currencies[idx % currencies.length],
    pnl_usd: Math.round((Math.random() * 2_000_000 - 500_000) * 100) / 100,
    var_95: Math.round(Math.random() * 500_000 * 100) / 100,
    delta_usd: Math.round((Math.random() * 1_000_000 - 200_000) * 100) / 100,
    trade_count: Math.floor(Math.random() * 500) + 10,
    cob_date: new Date().toISOString().split('T')[0],
    ...overrides,
  }));
}

export function generateClickHousePnLResponse(count = 10, overrides: Partial<PnLRecord> = {}): ClickHousePnLResponse {
  const data = generatePnLRecords(count, overrides);
  return {
    meta: [
      { name: 'trade_id', type: 'String' },
      { name: 'book', type: 'String' },
      { name: 'desk', type: 'String' },
      { name: 'currency', type: 'String' },
      { name: 'pnl_usd', type: 'Float64' },
      { name: 'var_95', type: 'Float64' },
      { name: 'delta_usd', type: 'Float64' },
      { name: 'trade_count', type: 'UInt32' },
      { name: 'cob_date', type: 'Date' },
    ],
    data,
    rows: data.length,
    statistics: { elapsed: 0.012, rows_read: 250_000, bytes_read: 4_500_000 },
  };
}
```

---

## ClickHouse Analytical Route Interception in Specs

```ts
test('should render ClickHouse columnar PnL stream in AG-Grid and chart widgets', {
  tag: ['@api', '@contract', '@ui'],
}, async ({ page, cockpitPage }) => {
  const mockResponse = generateClickHousePnLResponse(8);

  // 1. Intercept ClickHouse query endpoint before navigation
  await page.route('**/api/analytics/pnl**', async (route) => {
    // Validate that payload matches schema before fulfilling
    ClickHousePnLResponseSchema.parse(mockResponse);
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify(mockResponse),
    });
  });

  // 2. Visit cockpit and verify widgets render the data
  await cockpitPage.visit();
  await cockpitPage.pnlTableWidget.grid.expectRowCount(8);
  await cockpitPage.riskChartWidget.chart.expectRendered(8);
});
```

---

## Heavy Query Latency, Fault Injection & Network Resilience

### 1. Simulated Heavy Query Latency (Zero Test Sleep)
Simulate complex aggregation queries taking multiple seconds to evaluate UI loading overlays and skeletons:

```ts
await mockNetworkLatency('**/api/analytics/pnl**', 2000);

// In the test: verify that loading overlays appear, then vanish automatically
await cockpitPage.visit();
await expect(cockpitPage.pnlTableWidget.grid.loadingOverlay).toBeVisible();
await cockpitPage.pnlTableWidget.grid.expectLoadingHidden();
await cockpitPage.pnlTableWidget.grid.expectRowCount(10);
```

### 2. ClickHouse Query Timeout / Backend 504 Failure
Test frontend degradation and error recovery when analytical engines fail:

```ts
await mockNetworkFault('**/api/analytics/pnl**', 504, 'ClickHouse Analytical Query Timeout (30000ms)');

await cockpitPage.visit();
// The failing widget degrades visibly instead of crashing the dashboard
await cockpitPage.pnlTableWidget.container.expectError(/timeout/i);
await expect(cockpitPage.pnlTableWidget.container.body.getByRole('button', { name: /retry/i })).toBeVisible();

// Other widgets should remain operational
await expect(cockpitPage.netDeltaKpi.container.root).toBeVisible();
```

### 3. Connection Resets & Aborts (`route.abort`)
Simulate network-level resets and dropped connections:

```ts
await page.route('**/api/analytics/**', async (route) => {
  await route.abort('connectionreset'); // 'failed' | 'timedout' | 'connectionreset' | 'blockedbyclient'
});
```

### 4. Transient Failure & Retry Mocking
Verify that UI or HTTP client retry policies recover gracefully:

```ts
let attempt = 0;
await page.route('**/api/analytics/pnl**', async (route) => {
  attempt++;
  if (attempt === 1) {
    await route.fulfill({ status: 503, json: { error: 'ClickHouse Service Unavailable' } });
  } else {
    await route.fulfill({ status: 200, json: generateClickHousePnLResponse(5) });
  }
});
```

---

## APIClient (`e2e/helpers/apiClient.ts`)

Two modes, one class:

```ts
new APIClient(page)   // borrows page.request — shares cookies/storage with the browser
new APIClient()       // lazily creates its own APIRequestContext (baseURL from BASE_URL)
```

- It disposes **only** the context it created (`ownsContext`); a borrowed one belongs to the page.
  Always `await client.dispose()` in a `finally` when you constructed it yourself.
- `getValidated(url, schema)` / `postValidated(url, payload, schema)` throw on non-2xx and then
  `parse` the body — use them instead of hand-rolling `res.json()` + a cast.
- `performAPILogin()` requires a `Page` (it writes `localStorage`) and throws a clear error without
  one, so a mis-constructed client fails at the call site rather than as a mystery auth miss.
- `seedUser` / `deleteUser` are the extension points: swap the `console.log` for a real
  `context.post('/api/admin/users', …)` when a backend exists.

---

## Synthetic data + automatic teardown

```ts
test('isolated entity lifecycle', { tag: ['@api', '@smoke'] }, async ({ createdUser }) => {
  expect(createdUser.id).toBeDefined();     // seeded before the body, deleted after it
});
```

`generateUserData(overrides)` produces a UUID id, a random-suffixed email and token, so parallel
workers never collide. Pass overrides for the one field a test cares about
(`generateUserData({ role: 'admin' })`) and let the rest stay random. **Never** reuse a fixed
record across tests — `fullyParallel: true` plus sharding makes that a race.

Any new entity fixture follows the same three beats: seed → `await use(entity)` → delete in
`try`/`finally`.

---

## Route precedence rules

- **Precedence: the most recently registered matching handler wins.** `telemetryFixture` registers
  `**/api/**` for every test, so a spec-level `page.route('**/api/data/**')` registered afterwards
  takes over — and if it calls `fulfill`, the telemetry headers are not applied to that request.
  Register mocks inside the test body (after fixtures have run), and use `page.unroute(pattern)`
  when a single test needs to hand a URL back.
- Match narrowly. A broad `**/api/**` stub in one test silently starves every other request on the
  page, including the ones the app needs to render.
- Route handlers run in Node, so `console.log` inside them lands in terminal output, not the
  browser console.

---

## File download verification

When testing exports (PnL CSVs, Excel risk reports, PDF valuation statements), verify streams in memory rather than leaving untracked files on the filesystem:

```ts
test('should export PnL report to CSV without disk clutter', { tag: ['@api', '@ui'] }, async ({ page }) => {
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: /export csv/i }).click();
  const download = await downloadPromise;

  expect(download.suggestedFilename()).toMatch(/pnl-report-.*\.csv$/i);

  // Read data stream directly into memory
  const stream = await download.createReadStream();
  expect(stream).toBeDefined();

  // Clean up downloaded file artifact
  await download.delete();
});
```

---

## Telemetry correlation

`telemetryFixture` injects a W3C `traceparent`, `x-e2e-test-title` and `x-e2e-worker-index` into
every `**/api/**` request, so a backend trace can be tied back to the exact test and worker.
Request the `traceId` fixture in a spec when you need to assert or log the correlation id.

Caveat: only add global headers to first-party API patterns. Injecting custom headers into
cross-origin CDN or third-party requests turns simple GETs into CORS preflights that then fail.

---

## Checklist for a mocking test

- [ ] Pattern is as narrow as the endpoint it stubs (e.g. `**/api/analytics/pnl**`)
- [ ] Stub registered inside the test body, before the action that triggers the request
- [ ] Response validated with `schema.parse(...)` rather than trusted blindly
- [ ] UI-level assertion proves the app's behavior (table rows, chart points, error cards)
- [ ] Anything seeded is torn down; anything constructed is disposed
- [ ] Tagged `@api` plus `@contract` or `@resilience`
