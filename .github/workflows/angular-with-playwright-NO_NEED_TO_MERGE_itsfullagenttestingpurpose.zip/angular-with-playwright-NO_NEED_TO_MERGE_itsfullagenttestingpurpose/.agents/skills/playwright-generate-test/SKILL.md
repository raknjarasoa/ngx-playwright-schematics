---
name: playwright-generate-test
description: Generate a Playwright test from a described scenario by driving the real application step by step with Playwright MCP, then conform the result to this suite's fixture, page-object and tagging conventions and save it into e2e/specs/. Use when asked to generate, record, capture or reverse-engineer a test from a user scenario, user journey, bug repro or manual test case.
---

# Test Generation with Playwright MCP

Generate a Playwright test for the provided scenario **after** completing every prescribed step —
never from the scenario text alone.

## Prerequisite — the MCP server

This skill drives the app through the **Playwright MCP** server, which is **not configured in this
repo**: `.vscode/mcp.json` registers only `angular-cli`, and there is no `.mcp.json`. Add it first:

```bash
claude mcp add playwright -- npx -y @playwright/mcp@latest
```

Without it, fall back to the recorder — it produces the same raw interaction log, already signed in:

```bash
npm run e2e:codegen    # playwright codegen http://localhost:4200 --load-storage=e2e/auth/default.json
```

Either way the app must be running (`npm start`, or let `webServer` boot it).

## Specific instructions

- You are given a scenario, and you generate a Playwright test for it. If the user does not provide
  a scenario, ask them for one.
- **DO NOT** generate test code prematurely, or from the scenario alone, without completing all the
  prescribed steps.
- **DO** run the steps one at a time with the Playwright MCP tools, observing the real DOM after
  each one — the accessible names and roles you capture here are the whole point of the exercise.
- Only after all steps are complete, emit a Playwright TypeScript test based on the message history.
- Save it as **`e2e/specs/<feature>.spec.ts`** — that is this project's `testDir`. There is no
  `tests/` directory; do not create one.
- Execute the test and iterate until it passes.

## Conform the output before saving

Recorder and MCP output is raw and does **not** match this suite's architecture. Convert it first —
an unconverted generated test violates the rules in `.claude/CLAUDE.md`:

| Raw generated output | What this repo requires |
| :-- | :-- |
| `import { test, expect } from '@playwright/test'` | `import { test, expect } from '@fixtures/index'` |
| `await page.goto('/view')` | a page object's `visit()`, with the path registered in `pages/routes.ts` |
| inline `page.locator('div > .btn')` chains in the test body | locators moved into a page or component object — a spec never sees a selector |
| `page.getByTestId('x')` | `locator('[data-test="x"]')` — `testIdAttribute` is unset, so `getByTestId` matches nothing here |
| positional `.nth(2)` / structural CSS | role-first locators, with `.or()` fallbacks for en/fr labels |
| `await page.waitForTimeout(500)` | a web-first assertion for the state actually being awaited |
| untagged `test('...', async () => {})` | `test('should …', { tag: ['@smoke', '@ui'] }, async ({ … }) => {})` |
| bare action sequences | actions wrapped in `test.step('…')` inside the page/component object |

The captured accessible names are the valuable part; the generated *structure* is disposable. When
the scenario introduces a new screen or widget, build the objects first — load
`playwright-page-component-objects`, and follow `playwright-add-feature-test` for the full order.

## Finish

```bash
npm run e2e:validate                              # eslint + tsc --noEmit + --list
npx playwright test e2e/specs/<feature>.spec.ts   # iterate until green
```

Re-run once more before declaring success — a test that passes only on the first run is not done.
