---
name: playwright-locators-and-assertions
description: Locator and assertion rules for this Playwright suite — role-first selection priority, the .or() strict-mode trap, filtering and scoping, AG-Grid and Highcharts selector recipes, financial number parsing, web-first assertions, toPass/poll/soft, and the zero-sleep rule. Use when picking a selector, asserting on grids or charts, writing expect() calls, or eliminating flakiness.
---

# Locators & Assertions

This skill owns **locator choice, the zero-sleep rule, and assertion style**. Object structure is
owned by `playwright-page-component-objects`; tags by `playwright-ci-and-telemetry`.

## Selection priority — stop at the first that works

```
1. getByRole()        buttons, headings, dialogs, rows, cells, tabs, comboboxes
2. getByLabel()       form inputs with <label> or aria-label
3. getByPlaceholder() search / input placeholders
4. getByText()        static copy and assertions
5. [data-test="…"]    dedicated test hooks
6. CSS / XPath        last resort only — raw SVG, canvas, third-party widget internals
```

The higher you are, the closer the test is to what a user (and a screen reader) perceives, and the
less it breaks on refactors. A role locator survives a class rename; `div.container > table >
tr:nth-child(2)` survives nothing.

> **`getByTestId()` does not work here.** `testIdAttribute` is unset in `playwright.config.ts`, so
> `getByTestId('x')` looks for `data-testid` while this app uses `data-test`. Write
> `locator('[data-test="x"]')`, or prefer a semantic role locator.

| Intent | Locator |
| :-- | :-- |
| Button, fuzzy name | `getByRole('button', { name: /save changes/i })` |
| Button, exact name | `getByRole('button', { name: 'Save', exact: true })` |
| Heading at a level | `getByRole('heading', { level: 1, name: /dashboard/i })` |
| Input by its label | `getByLabel(/email address/i)` |
| Search box | `getByPlaceholder(/search columns/i)` |
| Dialog | `getByRole('dialog', { name: /confirm delete/i })` |
| Selected tab | `getByRole('tab', { name: /settings/i, selected: true })` |
| Select / combobox | `getByRole('combobox', { name: /datasource/i })` |
| Option in a listbox | `getByRole('listbox').getByRole('option', { name: /france/i })` |

## `.or()` — i18n and hook fallbacks

The app is bilingual (en/fr) and only selectively instrumented, so locators are written as a
preference chain:

```ts
this.applyButton = this.root
  .getByRole('button', { name: /apply|appliquer/i })
  .or(this.root.locator('[data-test="apply-groupings"]'));
```

**The strict-mode trap:** `.or()` returns the *union*, not the first non-empty branch. If the button
has both an accessible name and a `data-test` hook, the union holds two elements and any action
throws `strict mode violation: resolved to 2 elements`. Two fixes:

```ts
// (a) make the branches mutually exclusive — prefer this
page.getByRole('heading', { level: 1 })       // semantic
    .or(page.locator('h1:not([role])'));      // only matches when the role query cannot

// (b) collapse deliberately — what HeaderComponent does
await expect(this.titleHeading.first()).toBeVisible();
```

The same trap applies to `toHaveCount()` on an `.or()` chain: you are counting the union, not the
branch that matched. Scope the count to one unambiguous locator.

`.and()` intersects instead: `getByRole('tab').and(page.locator('[aria-selected="true"]'))`.

## Narrowing: filter, chain, scope

```ts
// Row containing a cell, then the action inside that row
const userRow = page.getByRole('row').filter({
  has: page.getByRole('cell', { name: 'Alice Dupont', exact: true }),
});
await userRow.getByRole('button', { name: /edit/i }).click();

page.getByRole('listitem').filter({ hasNot: page.getByText(/archived/i) });  // negative filter

// ARIA state as part of the query
page.getByRole('checkbox', { name: /terms/i, checked: true });
page.getByRole('button',   { name: /filters/i, expanded: true });
```

Inside a component object every locator is built from `this.root` — the strongest narrowing there
is. It keeps the widget reusable and keeps strict mode satisfied when the widget appears twice.

`.first()` / `.nth(i)` are acceptable only to collapse a *known* ambiguity you cannot remove. Never
to paper over a locator you have not understood.

---

## AG-Grid

The interaction methods live in `AgGridComponent` (`e2e/components/agGrid.component.ts`) — call
those rather than re-deriving selectors. What follows is the selector layer, for when you extend
that component or debug it.

```
.ag-root-wrapper                      grid root
  .ag-header-row
    .ag-header-cell[col-id="pnl_usd"] header, carries aria-sort="ascending|descending|none"
  .ag-row[row-id="1042"]              row, carries aria-expanded on group rows
    .ag-cell[col-id="pnl_usd"]        cell
  .ag-overlay-loading-center          query in flight
.ag-popup .ag-filter | .ag-menu       filter & column menus — BODY-LEVEL PORTAL, not under root
```

Three rules that prevent most grid flakiness:

1. **Address by `row-id` / `col-id`, never by index.** Sorting and filtering renumber positions.
2. **Rows are virtualized** — a row in the row model may have no DOM node. Call
   `scrollIntoViewIfNeeded()` before reading a cell (`AgGridComponent.getCellValue` already does).
3. **Menus escape the grid root.** Locate `.ag-popup` from `page`, everything else from `this.root`.

**Enterprise-only** — row grouping, pivot mode and the tool panel (`.ag-side-buttons`,
`.ag-pivot-mode-panel`, `.ag-group-contracted`) render no DOM under AG-Grid Community. Confirm the
licence before writing a test against them.

Cell text is a display string, so parse before comparing numerically:

```ts
import { parseFinancialNumber } from '@helpers/financial';  // "$1,234.56" → 1234.56, "(4,520)" → -4520

const pnl = await cockpitPage.pnlTableWidget.grid.getFinancialCellValue('1042', 'pnl_usd');
expect(pnl).toBeGreaterThan(0);
```

## Highcharts

Interaction methods live in `HighchartsComponent` (`e2e/components/highcharts.component.ts`).

```
.highcharts-container                 chart root
  svg.highcharts-root
    .highcharts-series-group
      .highcharts-series-0            one series
        .highcharts-point             one datum
    .highcharts-legend
      .highcharts-legend-item         toggles a series; gains -hidden when off
    .highcharts-tooltip               inside the SVG by default…
body > .highcharts-tooltip-container  …or a body portal when tooltip.outside is set
```

Charts have no roles — SVG class names are the only handle, which is the sanctioned drop to
priority level 6. Never assert a chart is ready by asserting the SVG exists; assert a **drawn mark**
exists, which is what `expectRendered()` does. That is also how you wait out the entry animation
without sleeping.

---

## PrimeNG UI Components

Standard component objects live in `@components/primeng/` (`PrimeDropdownComponent`, `PrimeTableComponent`,
`PrimeDatePickerComponent`, `PrimeMultiSelectComponent`, `PrimeDialogComponent`, `PrimeToastComponent`).

```
p-dropdown / p-select                 trigger inside widget root (.p-dropdown, .p-select)
body > .p-dropdown-panel              OVERLAY PORTAL — mounted at <body>, not inside widget root
p-table / .p-datatable                table root (.p-datatable-tbody, .p-paginator)
p-dialog / .p-dialog                  dialog root (.p-dialog-header, .p-dialog-content, .p-dialog-footer)
p-toast / .p-toast                    alert messages (.p-toast-message-success, .p-toast-summary)
```

### Key PrimeNG Rules:

1. **Overlays portal to `<body>`**: Dropdown (`p-dropdown`), multi-select (`p-multiselect`), calendar (`p-calendar`),
   and overlay panel panels are mounted under `document.body` via `appendTo="body"`. Locate the trigger from
   `this.root`, but locate the active overlay panel (`.p-dropdown-panel`, `.p-datepicker`) from `page`.
2. **Animation-safe assertions**: PrimeNG dialogs and dropdowns use CSS entry transitions. Rely exclusively
   on `expect(overlay).toBeVisible()` before clicking options to ensure transition completion without `waitForTimeout`.
3. **Table Row Addressability**: In `p-table`, locate rows via semantic text filters or unique cell attributes
   rather than DOM row indices that change on sort/filter.

---

## Web-first assertions only

`expect(locator)` retries until `expect.timeout` (15s local, 30s CI). That retry loop replaces every
wait you were about to write.

| Need | Assertion |
| :-- | :-- |
| Element appeared | `await expect(loc).toBeVisible()` |
| Element gone (dialog closed, spinner finished) | `await expect(loc).toBeHidden()` |
| Exact number of rows/chips | `await expect(loc).toHaveCount(3)` |
| Nothing matched | `await expect(loc).toHaveCount(0)` |
| Text | `toHaveText` (exact) · `toContainText` (substring) |
| Field value | `await expect(input).toHaveValue('Country')` |
| Enablement / checked | `toBeEnabled` · `toBeDisabled` · `toBeChecked` |
| Attribute / class / a11y name | `toHaveAttribute` · `toHaveClass` · `toHaveAccessibleName` |
| Navigation landed | `await expect(page).toHaveURL(/\/cockpit/)` |

Add a message when the failure would be cryptic — it surfaces in the HTML and Allure reports:

```ts
await expect(this.emailInput, 'Verify login email field is visible').toBeVisible();
```

### `expect(…).toPass()` — a composite condition that settles

For a state no single locator expresses, e.g. grid and chart both reflecting a new filter:

```ts
await expect(async () => {
  await expect(cockpitPage.pnlTableWidget.grid.rows).toHaveCount(15);
  await expect(cockpitPage.riskChartWidget.chart.getSeries(0).locator('.highcharts-point')).toHaveCount(15);
}).toPass({ timeout: 10_000, intervals: [250, 500, 1000] });
```

### `expect.poll()` — an async getter that is not a locator

```ts
await expect
  .poll(() => cockpitPage.pnlTableWidget.grid.getFinancialCellValue('1042', 'pnl_usd'), {
    message: 'Wait for PnL to settle above zero',
    timeout: 10_000,
  })
  .toBeGreaterThan(0);
```

### `expect.soft()` — collect several independent failures

Report all mismatched KPI cards in one run instead of stopping at the first. **Specs only — never
inside a page or component object**, which must fail fast.

```ts
await expect.soft(cockpitPage.netDeltaKpi.metricValue).toContainText('+$1.2M');
await expect.soft(cockpitPage.netDeltaKpi.deltaBadge).toContainText('+4.2%');
```

## Zero sleeps

| ❌ Never | ✅ Instead |
| :-- | :-- |
| `page.waitForTimeout(500)` | `await expect(target).toBeVisible()` |
| `await new Promise(r => setTimeout(r, 500))` | the assertion for the state you are waiting on |
| `waitForSelector` in new code | `expect(locator).toBeVisible()` |
| Sleeping after `click()` | Playwright already awaits actionability before acting |
| Sleeping for a spinner | `await loaderComponent.waitForFinishLoading()` |
| Sleeping for a chart animation | `await chart.expectRendered()` |
| Sleeping after navigation | assert the landing state in `visit()` |

**Scope of the rule:** banned in specs, page objects and component objects — the browser-driving
layers. A `setTimeout` **inside a route handler** is a different thing: it delays a mocked
*response*, it does not sleep the test. That is why `dataFactoryFixture.ts` uses one in
`mockNetworkLatency`, and it is legitimate.

`page.waitForResponse` / `waitForRequest` are legitimate when you genuinely need the network event —
start them *before* the action that triggers the request.

## Anti-patterns

```ts
// ❌ Structural CSS — breaks on any markup change
page.locator('div.container > table > tr:nth-child(2) > td > button.btn-primary');
// ✅ Semantic
page.getByRole('row').filter({ hasText: 'Alice' }).getByRole('button', { name: /edit/i });

// ❌ Assertion on a stale snapshot — no retry
expect(await loc.textContent()).toBe('Saved');
// ✅ Web-first, auto-retrying
await expect(loc).toHaveText('Saved');

// ❌ isVisible() as a gate — returns instantly, never waits
if (await loc.isVisible()) { … }
// ✅ assert it, or use the sanctioned no-throw probe
```

`ModalComponent.isOpen()` is the one sanctioned exception: a fast non-throwing probe used only to
decide *whether* a close click is needed — never to gate an assertion.
