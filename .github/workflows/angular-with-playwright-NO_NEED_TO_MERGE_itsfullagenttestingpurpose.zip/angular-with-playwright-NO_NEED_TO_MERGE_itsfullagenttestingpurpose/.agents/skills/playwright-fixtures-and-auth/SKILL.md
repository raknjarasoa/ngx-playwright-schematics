---
name: playwright-fixtures-and-auth
description: Fixture composition and authentication for this Playwright suite — the seven mergeTests slices and which one a new fixture belongs in, fixture anatomy (setup/use/teardown, scopes, auto), page-vs-component-fixture placement, and pre-cached storageState auth with role personas, credential handling and unauthenticated opt-out. Use when adding or debugging a fixture, wiring dependency injection into specs, or working on login, sessions, roles or e2e/auth/*.json.
---

# Fixtures & Authentication

This skill owns **fixture placement and `storageState` auth**. Which object goes in a fixture at
all is decided by `playwright-page-component-objects`.


## The seven slices

`e2e/fixtures/index.ts` fuses everything with `mergeTests()`; specs import `{ test, expect }` from
`@fixtures/index` and get all of it by destructuring.

| Slice | File | Provides | Put here |
| :-- | :-- | :-- | :-- |
| Pages | `pageFixtures.ts` | `routes`, `homePage`, `loginPage`, `viewPage` | one entry per route/screen |
| Components | `componentFixtures.ts` | `toastComponent`, `loaderComponent`, `headerComponent`, `modalComponent` | **global chrome only** |
| API | `apiFixtures.ts` | `api` (`APIClient` bound to `page`) | HTTP clients |
| Data | `dataFactoryFixture.ts` | `createdUser`, `mockNetworkFault`, `mockNetworkLatency` | seeding, teardown, fault injection |
| A11y | `a11yFixture.ts` | `makeAxeBuilder`, `checkA11y` | accessibility scanners |
| Telemetry | `telemetryFixture.ts` | `traceId` (injects W3C `traceparent`) | request correlation |
| Custom | `fixtures.ts` | `appTitle`, `appTitleDisplay`, `defaultUserRole` | static test data |

Adding a fixture to an existing slice needs **no change to `index.ts`**. Only a brand-new slice
gets appended to the `mergeTests(...)` call — and then it must be a genuinely new concern, not a
seventh place to put page objects.

## Where does a new fixture go?

```
Is it a Page Object for a route?              → pageFixtures.ts
Is it a widget that can appear on any screen? → componentFixtures.ts
Is it a widget one page opens?                → NOT a fixture — the page constructs it
Does it talk HTTP / seed / clean data?        → apiFixtures.ts or dataFactoryFixture.ts
Is it a static value or flag?                 → fixtures.ts
Anything else (scanner, tracing, clock)       → its own slice + register in index.ts
```

## Fixture anatomy

```ts
export const dataFactoryFixture = base.extend<DataFactoryFixtures>({
  createdUser: async ({}, use) => {
    const apiClient = new APIClient();
    const testUser = generateUserData();

    await apiClient.seedUser(testUser);   // 1 · setup, before the test body
    await use(testUser);                  // 2 · hand it to the test
    try {                                 // 3 · teardown, after the test body
      await apiClient.deleteUser(testUser.id);
    } finally {
      await apiClient.dispose();          //     release owned resources, always
    }
  },
});
```

Rules:

- Everything after `await use(...)` is teardown and **always runs**, including after a failure.
- Resource disposal goes in `finally` so a failing cleanup call still releases the context.
- `async ({}, use)` — the empty destructure means "no dependencies"; it is intentional, not a typo.
- Depend on other fixtures by naming them: `async ({ page, headerComponent }, use) => …`. Playwright
  resolves the graph and instantiates in order.
- Factory fixtures (a function handed to the test) are how `mockNetworkFault`, `mockNetworkLatency`
  and `checkA11y` take per-call arguments.
- Default scope is per-test. Only use `{ scope: 'worker' }` for genuinely expensive, shareable
  setup — worker-scoped state leaks between tests by design.
- `{ auto: true }` runs a fixture even when a test doesn't request it; use sparingly.
- `testInfo` is the third parameter and is how a fixture attaches artifacts
  (`testInfo.attach(...)` in `a11yFixture`) or reads `title` / `workerIndex`.
- Name collisions across slices are silently resolved by `mergeTests` order — keep names unique.

## Authentication

### How it works

1. `e2e/specs/auth.setup.ts` runs in the `setup` project (`testMatch: /.*\.setup\.ts/`).
2. It logs in per persona (via `api.performAPILogin`, which seeds `localStorage`) and writes
   `e2e/auth/<role>.json` with `page.context().storageState({ path })`.
3. `Chrome` and `Firefox` declare `dependencies: ['setup']` and
   `use: { storageState: 'e2e/auth/default.json' }`, so every test starts already signed in.
4. CI runs `npm run e2e:auth` as its own step first, so a credential failure fails fast and loudly
   instead of surfacing as 40 mysterious UI failures.

### Selecting a persona in a spec

```ts
test.describe('Admin-only settings', () => {
  test.use({ storageState: 'e2e/auth/admin.json' });   // persona
  // …
});

test.describe('Unauthenticated Flow Opt-Out', () => {
  test.use({ storageState: { cookies: [], origins: [] } });  // guest
  // …
});
```

`test.use()` belongs at file or `describe` scope — never inside a `test()` body.

### Credentials

`e2e/fixtures/creds.ts` is the only source of accounts. Three personas exist:

| Persona | Source | Notes |
| :-- | :-- | :-- |
| `default` | `E2E_USER_EMAIL` / `E2E_USER_PASSWORD` | the storageState every browser project loads |
| `admin` | `E2E_ADMIN_EMAIL` / `E2E_ADMIN_PASSWORD`, falling back to the `E2E_USER_*` pair | elevated-permission specs |
| `guest` | hardcoded non-privileged account, no env vars | for specs that must be signed in as *someone* unprivileged — not the same as the unauthenticated opt-out above |

Adding a persona = an entry in `CredsManager.accounts` + a `test()` in `auth.setup.ts` that writes
its state file. Copy `.env.example` to `.env` locally; CI supplies GitHub secrets.

### Hard rules

- **Never commit `e2e/auth/*.json`** — it is gitignored and contains session material.
- **Never type credentials into the UI inside a feature spec.** UI login is exercised once, by the
  login spec/setup; everywhere else it is pure overhead and a flake source.
- **Never hardcode a real credential** in a spec, page object or fixture.
- Deleting `e2e/auth/` is the correct fix for a stale-session failure — the `setup` dependency
  regenerates it on the next run (`npm run e2e:auth`).
- `APIClient.performAPILogin()` throws without a `Page` — it writes `localStorage`, which needs a
  browser context. Construct it as `new APIClient(page)`.

## Debugging fixtures

- `npx playwright test --list` loads the entire fixture graph — a broken import or a circular
  dependency shows up here without running a browser.
- "Unknown fixture" in a spec: it was added to a slice that `index.ts` never merged, or the type
  was added to the `type` block but not to the `extend({...})` object (or vice versa).
- A fixture that looks like it did nothing: check whether the spec actually destructured it —
  Playwright only instantiates the fixtures a test names.

