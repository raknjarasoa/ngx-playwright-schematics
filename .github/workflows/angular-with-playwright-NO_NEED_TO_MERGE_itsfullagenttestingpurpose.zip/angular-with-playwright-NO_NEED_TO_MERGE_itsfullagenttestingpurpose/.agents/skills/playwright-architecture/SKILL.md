---
name: playwright-architecture
description: Map of this repo's Playwright E2E suite — layer boundaries, directory layout, path aliases, dependency direction, config conventions, and the pre-push validation gate. Use when orienting in e2e/, deciding which layer a piece of code belongs to, auditing or refactoring the suite, reviewing an E2E pull request, or when unsure which other playwright-* skill to load.
---

# Playwright E2E Architecture

This skill owns the **validation gate** and the layer boundaries. Locator rules live in
`playwright-locators-and-assertions`; object structure in `playwright-page-component-objects`.


The suite is an **external black-box consumer** of the Angular app. Nothing in `e2e/` may know how
`src/` is implemented.

## Which skill do I actually need?

| Task | Load |
| :-- | :-- |
| Structure a Page / Component / Widget object | `playwright-page-component-objects` |
| Add tests for a new feature end to end | `playwright-add-feature-test` |
| Pick a locator, write an assertion | `playwright-locators-and-assertions` |
| Add a fixture, wire DI, touch auth / `storageState` | `playwright-fixtures-and-auth` |
| Mock an API, seed data, Zod contract, inject a fault | `playwright-data-and-api-mocking` |
| Axe/WCAG spec or visual snapshot spec | `playwright-a11y-and-visual` |
| Tags, sharding, reporters, CI, insights dashboard | `playwright-ci-and-telemetry` |
| A spec fails or flakes and you don't know why | `playwright-debug-and-flake` |
| Ship the architecture to another Angular repo | `playwright-blueprint-schematic` |

## Layout and what each folder owns

```
e2e/
├── specs/       *.spec.ts, *.setup.ts  — the tests. Top-level assertions live only here.
├── pages/       *.ts                   — Page Objects (one per route) + routes.ts (URL registry)
├── components/  *.component.ts         — Component Objects (one per reusable widget)
├── fixtures/    *.ts                   — dependency injection (mergeTests) + constants/creds
├── helpers/     *.ts                   — non-UI utilities (apiClient, storage/url helpers)
├── auth/        <role>.json            — generated storageState (gitignored, never committed)
├── snapshots/   *.png                  — visual baselines, per project + platform
├── global/      global-setup/teardown  — process-wide env bootstrap and logging
└── tsconfig.json                       — path aliases; the typecheck entrypoint
```

## Dependency direction

Arrows point at what a layer may import. Nothing points back up, and nothing points at `src/`.

```mermaid
flowchart TD
  Spec["spec — view-groupings.spec.ts"] -->|"imports { test, expect }"| Index["fixtures/index.ts — mergeTests"]
  Index --> PageFx["pageFixtures"]
  Index --> CompFx["componentFixtures (global chrome only)"]
  Index --> Other["apiFixtures · dataFactory · a11y · telemetry · custom"]
  PageFx --> ViewPage["ViewPage (page object)"]
  ViewPage -->|owns / instantiates| Groupings["GroupingsModalComponent"]
  ViewPage -->|uses| Routes["Routes"]
  Groupings -->|composes| Modal["ModalComponent (generic shell)"]
  CompFx --> Toast & Loader & Header & Modal
```

**Golden rule:** a spec never sees a raw selector. Spec → page object → component object →
selectors. Selectors exist in exactly one layer.

## Where does this code go?

| Concern | Home |
| :-- | :-- |
| A selector, any selector | the component object that owns the widget (or the page, if the element is unique to that screen) |
| Widget interaction / widget-local assertion | component object |
| Navigation, screen-level assertions, widget ownership | page object |
| URL / path constants | `pages/routes.ts` |
| Object construction, DI | `fixtures/*` (merged in `fixtures/index.ts`) |
| API calls, auth, seed/teardown | `helpers/apiClient.ts` + `fixtures/dataFactoryFixture.ts` |
| Generic waits, localStorage reads | `helpers/utils.ts` |
| Timeouts, app title, nav labels | `fixtures/constants.ts` |
| Credentials / personas | `fixtures/creds.ts` (env-driven) |
| Cross-page user journeys | the spec body — not a page, not a component |

## Hard boundaries

1. **No `src/` imports.** Enforced by `no-restricted-imports` in `eslint.config.mjs`. Do not weaken it.
2. **Path aliases only** — `@components/* @pages/* @fixtures/* @helpers/* @global/* @specs/*`
   (declared in `e2e/tsconfig.json`). Never `../../components/…`.
3. **Specs import from `@fixtures/index`.** `@playwright/test` imports are allowed only inside
   page/component/fixture/helper modules. `e2e/pages/testExtender.ts` is a thin re-export of the
   same entrypoint; prefer `@fixtures/index` in new code.
4. **Named exports only.** No default exports anywhere in `e2e/`.
5. **Composition over inheritance.** There is no `BasePage` and there must never be one.

## Config conventions (`playwright.config.ts`)

- `testDir: './e2e/specs'` — a new file there is discovered automatically; nothing to register.
- `snapshotPathTemplate: '{snapshotDir}/{arg}-{projectName}-{platform}{ext}'` — keeps macOS and
  Linux baselines side by side instead of overwriting each other.
- Projects: `setup` (matches `*.setup.ts`) → `Chrome` / `Firefox`, both with
  `dependencies: ['setup']` and `storageState: 'e2e/auth/default.json'`.
- `webServer` boots `npm start` on `:4200` and reuses a running server outside CI.
- CI hardening: `forbidOnly`, `retries: 2`, `workers: 2`, longer `expect.timeout`.
- Reporters write everything under `artifacts/` (gitignored): html, allure, json, junit.

## Validation gate — run all three before pushing

```bash
npx eslint e2e                        # decoupling + lint
npx tsc -p e2e/tsconfig.json --noEmit # types + alias resolution (NOT tsconfig.spec.json)
npx playwright test --list            # loads the whole fixture/POM import graph; proves wiring
```

`npm run e2e:validate` runs all three in sequence.

They need no dev server and catch nearly everything structural. Then run the specs themselves
(`npm run e2e:smoke`, or `npx playwright test e2e/specs/<file>.spec.ts`).

## Review checklist for an E2E change

- [ ] No `src/` import, no relative climb-out, no default export
- [ ] Selectors confined to component/page objects; spec reads as prose
- [ ] Embedded widget owned by its page, **not** registered in `componentFixtures.ts`
- [ ] Every public action wrapped in `test.step(...)`
- [ ] Test tagged (`@smoke` / `@regression` / …)
- [ ] No `waitForTimeout`, no manual sleep
- [ ] New architecture file added to `filesToSync` in `schematics/scripts/sync-and-build.ts`
- [ ] All three validation-gate commands pass
