---
name: playwright-blueprint-schematic
description: Maintain and run the Angular ng-add schematic in schematics/ that scaffolds this Playwright E2E architecture into any Angular workspace — the live-file-to-template sync flow, the filesToSync list, what the schematic rewrites in angular.json/package.json/.gitignore/eslint.config.mjs, build and test commands, and the rule that templates are generated, never hand-edited. Use when the schematic breaks, when a new e2e/ or scripts/ file must ship with the blueprint, or when installing the blueprint into another project.
---

# Blueprint Schematic (`schematics/`)

> **Sandbox-only.** This schematic scaffolds the architecture into a *new* Angular workspace. It
> is not how guidance reaches a repo that already has an `e2e/` suite — there, the skills travel on
> their own. Only touch this when you are maintaining the blueprint itself.

The schematic packages this repo's E2E architecture so another Angular workspace can adopt it with
one command. **This repo is the source of truth; the templates are generated from it.**

## The one rule

> Never hand-edit anything under `schematics/src/ng-add/files/**.template`.
> Edit the real file at the repo root (`e2e/…`, `scripts/…`, `playwright.config.ts`), then re-sync.

`schematics/scripts/sync-and-build.ts` copies each path in its `filesToSync` array to
`schematics/src/ng-add/files/<path>.template`, overwriting whatever was there. A hand edit is
silently discarded on the next build.

```bash
npm run build:schematics    # sync templates → tsc → copy schema + files into schematics/dist
npm run test:schematics     # vitest over schematics/src/ng-add/index.spec.ts
```

## Adding a file to the blueprint

1. Create it in the repo and make it work here first.
2. Add its repo-relative path to `filesToSync` in `schematics/scripts/sync-and-build.ts`.
3. `npm run build:schematics`.
4. Extend `index.spec.ts` if the file is structurally important (the existing specs assert that the
   blueprint files land, that `package.json` gains scripts/deps, that `angular.json` gains the
   `architect.e2e` builder, and that existing files are resolved gracefully).

**Architecture ships; the example does not.** `viewPage.ts`, `groupingsModal.component.ts` and
`view-groupings.spec.ts` are deliberately absent from `filesToSync` — they are the local worked
example, not part of the scaffold. `homePage.ts`, `loginPage.ts`, `routes.ts`, the four generic
components, all fixture slices, helpers, global setup/teardown, the four blueprint specs, the
insights scripts and `src/app/core/interceptors/api-contract.interceptor.ts` all do ship.

A missing source path only logs `⚠️ Source file not found` and continues — so a typo in
`filesToSync` fails quietly. Check the sync output line (`✅ Synced N template files`) after adding.

## What `ngAdd` does to a target workspace

`schematics/src/ng-add/index.ts` chains six rules, each defensive — a failure logs a warning and
continues rather than aborting a half-applied install:

| Rule | Effect |
| :-- | :-- |
| `updateAngularJson` | adds `architect.e2e` (`playwright-ng-schematics:playwright`, `devServerTarget`) and registers the schematic collections; target project = `--project`, else `defaultProject`, else the first project |
| `updatePackageJson` | merges `e2e:*`, `allure:*`, `insights:*`, `lint*` scripts and Playwright/axe/allure/zod deps, key-sorted |
| `updateGitignore` | adds `artifacts/`, `e2e/auth/`, `blob-report/`, report folders |
| `updateEslintConfig` | injects the `no-restricted-imports` guardrail forbidding `src/**` imports inside `e2e/**` |
| `scaffoldBlueprintFiles` | `apply(url('./files'))` + `applyTemplates` (which strips the `.template` suffix); `forEach` honours `--overwrite` on existing paths |
| `scheduleTasks` | `NodePackageInstallTask`, plus `install-browsers` when `--installBrowsers` |

## Running it

```bash
npm run build:schematics
ng g ./schematics:ng-add
ng g ./schematics:ng-add --project=my-app --installBrowsers=true --overwrite=true
```

Options (`schematics/src/ng-add/schema.json`): `project` (defaults to the workspace project),
`installBrowsers` (default `false`, prompted), `overwrite` (default `true` — set `false` to keep
existing files untouched). `collection.json` exposes the same factory as both `ng-add` and
`blueprint`, and points at `./dist/...`, so **the schematic must be built before it can run**.

## Gotchas

- `schematics/dist` is gitignored; a fresh clone must run `npm run build:schematics` before `ng g`.
- Editing `index.ts` requires a rebuild — `ng g` executes the compiled `dist` output, not the source.
- The interceptor template writes into the consumer's `src/`; it still has to be registered by hand
  in their `app.config.ts` (`provideHttpClient(withInterceptors([apiContractInterceptor]))`).
- There is no prose copy of the architecture to consult — the live files under `e2e/` are the only
  source of truth, and `filesToSync` is the list of which ones ship.
- **`pageFixtures.ts` and `componentFixtures.ts` are synced verbatim, so every page and component
  they import must also be in `filesToSync`** — otherwise the scaffolded workspace fails `tsc` on a
  missing module. This is why `viewPage.ts` and `groupingsModal.component.ts` ship despite being
  feature examples. Only `view-groupings.spec.ts` stays out: no fixture references a spec.
