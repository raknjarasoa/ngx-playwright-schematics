---
name: playwright-add-feature-test
description: Ordered playbook for adding end-to-end tests for a new feature, page, modal or user flow in this Playwright suite — route registration, component object, page object, fixture wiring, spec authoring, tagging, and the validation gate — plus the isolation and parallelism rules that keep a growing suite fast and non-flaky. Use whenever asked to write, scaffold or extend E2E tests for new application functionality.
---

# Adding a Feature Test

This is the ordered playbook. It restates rules for checklist use — the authoritative versions
live in `playwright-page-component-objects` (structure), `playwright-locators-and-assertions`
(selectors, sleeps) and `playwright-ci-and-telemetry` (tags).


Worked reference: the **Groupings** feature on `/view`
(`e2e/pages/viewPage.ts`, `e2e/components/groupingsModal.component.ts`, `e2e/specs/view-groupings.spec.ts`).
Read those three files side by side — they are the smallest complete slice in the suite.

## The order (do not shuffle it)

```mermaid
flowchart TD
  A["1 · Route<br/>pages/routes.ts"] --> B["2 · Reuse the shell<br/>components/modal.component.ts"]
  B --> C["3 · Component Object<br/>components/&lt;widget&gt;.component.ts"]
  C --> D["4 · Page Object (owns the widget)<br/>pages/&lt;feature&gt;Page.ts"]
  D --> E["5 · Register the page fixture<br/>fixtures/pageFixtures.ts"]
  E --> F["6 · Spec<br/>specs/&lt;feature&gt;.spec.ts"]
  F --> G["7 · Validate<br/>eslint · tsc · --list"]
  G --> H["8 · Run<br/>playwright test"]
```

Bottom-up on purpose: each layer is finished and typed before the layer above consumes it, so the
spec you write last needs no rework.

**Accelerator:** `npm run e2e:scaffold <featureName>` (`scripts/scaffold-feature.ts`) generates
steps 3–6 — component object composing `ModalComponent`, page object owning it, the route key, the
`pageFixtures` entry and a tagged spec — from one name, in this architecture's conventions. It is a
starting point, not the finish line: the generated locators are guesses that you must replace with
the real accessible names, and the generated spec asserts placeholder behaviour. Read every
generated file before running it.

### 1 — Register the route
Add the key to `Routes.paths` in `e2e/pages/routes.ts` and, if it is a frequent destination, a
typed helper (`goToView()`). Every URL in the suite comes from here.

### 2 — Reuse the generic shell
Dialog? It composes `ModalComponent` — do not re-declare root/title/close. Needs a close label or
`data-test` hook that doesn't resolve? Add it *in* `ModalComponent` so every dialog benefits.
Not a dialog? Skip to step 3 and write a standalone component object.

### 3 — Component object
`e2e/components/<widget>.component.ts`. Optional `rootLocator`, all children scoped to `this.root`,
role-first locators with `.or()` i18n/test-hook fallbacks, every public method in a `test.step`.
Details and skeleton: load `playwright-page-component-objects`.

### 4 — Page object
`e2e/pages/<feature>Page.ts`. Owns `visit()`, the screen's unique locators, and **instantiates the
widget in its constructor**. Screen-level verifications compose its own locators.

### 5 — Register the page fixture
Add the property to `PageFixtures` and the factory to `pageFixtures` in
`e2e/fixtures/pageFixtures.ts`. **Do not** add the embedded widget to `componentFixtures.ts` —
that would hand the spec a second, unopened instance. `fixtures/index.ts` only changes if you are
introducing a whole new fixture *slice*.

### 6 — Spec
`e2e/specs/<feature>.spec.ts` — discovered automatically via `testDir`.

```ts
import { test, expect } from '@fixtures/index';

test.describe('View Page - Groupings Feature Specification', () => {
  test.beforeEach(async ({ viewPage }) => {
    await viewPage.visit('/view');
  });

  test(
    'should open groupings modal, search column, and apply groupings to the table',
    { tag: ['@smoke', '@regression', '@ui'] },
    async ({ viewPage }) => {
      await viewPage.openGroupingsModal();
      await viewPage.groupingsModal.searchColumn('Country');
      await viewPage.groupingsModal.dragAndDropColumn('Country');
      await viewPage.groupingsModal.apply();
      await viewPage.verifyTableVisible();
      await viewPage.verifyTableGroupedBy('Country');
    },
  );
});
```

### 7–8 — Validate, then run
```bash
npm run e2e:validate                                   # eslint + tsc --noEmit + --list
npx playwright test e2e/specs/<feature>.spec.ts --ui   # or --headed while iterating
```

## How to slice a feature into tests

One `describe` per feature/screen; one `test` per **user-observable outcome**, not per click.
For a typical CRUD-ish widget that means roughly:

| Test | Tags |
| :-- | :-- |
| The happy path a user actually performs | `@smoke @regression @ui` |
| Each meaningful alternative (reset, cancel/dismiss, validation error) | `@regression @ui` |
| Empty / error state driven by a mocked response | `@regression @resilience` |
| The screen passes an axe audit | `@a11y @regression` |

Keep `@smoke` genuinely small — it runs on every PR (`npm run e2e:smoke`). If a test is not a
release blocker, it is not smoke.

## Rules that keep the suite scalable

1. **Every test is independent.** `fullyParallel: true` and CI sharding mean tests run in any
   order, in any worker, on any shard. Never let test B depend on state test A left behind.
2. **Set state in `beforeEach` through the page object**, not by relying on the previous test.
3. **Never log in through the UI in a feature spec.** Auth is pre-cached into
   `e2e/auth/<role>.json` by the `setup` project. Need a different persona:
   `test.use({ storageState: 'e2e/auth/admin.json' })`. Need none:
   `test.use({ storageState: { cookies: [], origins: [] } })`.
4. **Data must be unique per test.** Use the `createdUser` factory (UUID + random suffix) or mock
   the endpoint; two workers hitting the same fixed record will fight.
5. **Clean up what you create**, in the fixture's post-`use` phase with disposal in `finally`.
6. **No `waitForTimeout`.** Auto-waiting assertions only — sleeps are what turn a 40-test suite
   into a 20-minute one.
7. **Prefer mocking a backend you don't own** (`page.route`) over depending on its uptime; keep
   real-backend coverage in a small, deliberately tagged set.
8. **Reuse before you add.** A new component object is only justified when no existing widget
   covers the DOM you are driving; check `e2e/components/` first.
9. **Tag on the way in.** Retro-tagging never happens, and untagged tests are invisible to the
   `e2e:*` scripts and CI filters.
10. **Adding an architecture-level file?** Add it to `filesToSync` in
    `schematics/scripts/sync-and-build.ts` (feature-example files stay out — see
    `playwright-blueprint-schematic`).

## Rename map when copying the example

| Groupings example | Yours |
| :-- | :-- |
| `view` key in `routes.ts` | your route key + path |
| `pages/viewPage.ts` → `ViewPage` | `pages/<feature>Page.ts` → `<Feature>Page` |
| `components/groupingsModal.component.ts` → `GroupingsModalComponent` | `components/<widget>.component.ts` → `<Widget>Component` |
| `viewPage` fixture | `<feature>Page` fixture |
| `specs/view-groupings.spec.ts` | `specs/<feature>.spec.ts` |

## Done checklist

- [ ] Route key in `routes.ts`
- [ ] Component object: composes the shell if a dialog, optional `rootLocator`, `test.step` actions
- [ ] Page object: `visit()`, screen locators, **owns** the widget
- [ ] `pageFixtures.ts` updated · `componentFixtures.ts` untouched
- [ ] Spec imports `@fixtures/index`, tagged, page-driven, zero selectors, zero sleeps
- [ ] `eslint` · `tsc --noEmit` · `playwright test --list` all green
- [ ] Spec passes locally, and passes again when re-run (`--repeat-each=3` for anything suspicious)
