---
name: playwright-debug-and-flake
description: Triage and fix failing or flaky Playwright specs in this suite — the debug toolkit (UI mode, traces, repeat-each, last-failed), a symptom-to-root-cause table for strict mode violations, locator and test timeouts, unknown fixtures, storageState and webServer errors, plus flakiness root causes, reproduction technique, and the quarantine policy. Use when a spec fails, times out, passes locally but fails in CI, or is intermittently red.
---

# Debugging & De-flaking

The zero-sleep rule this skill enforces is defined in `playwright-locators-and-assertions`.


## Toolkit, in the order you should reach for it

```bash
npx playwright test --ui                                  # 1 · time travel, watch mode, DOM per step
npx playwright test e2e/specs/<spec>.spec.ts --headed          # 2 · watch it happen in a real browser
npx playwright test --last-failed                         # 3 · rerun only what broke
npx playwright test e2e/specs/<spec>.spec.ts --trace on        # 4 · force a trace even on the first run
npx playwright show-trace test-results/<dir>/trace.zip    #     open it
npx playwright test -g "should apply groupings" --workers=1 --reporter=list
npx playwright test --repeat-each=10 --workers=4          # 5 · prove a flake exists
npm run e2e:report                                        #     the HTML report, with video + screenshot
```

`await page.pause()` inside a test opens Inspector at that exact point — the fastest way to try
locators against the live DOM. Remove it before committing (and note `forbidOnly` fails CI on a
stray `test.only`).

A trace gives you the action log, before/after DOM snapshots, network, and console per step. For
CI-only failures download the run artifacts — `trace: 'on-first-retry'` means the retry attempt
already recorded one.

## Symptom → cause

| Message | Usual cause | Fix |
| :-- | :-- | :-- |
| `strict mode violation: resolved to N elements` | an `.or()` chain whose branches both match, or a locator built from `page` instead of `this.root` | make branches mutually exclusive, scope to the widget root, or collapse with `.first()` |
| `Timeout waiting for expect(locator).toBeVisible()` — 0 elements | wrong role/accessible name, element inside an iframe, or it never rendered because a route stub starved the request | check the trace's DOM snapshot; widen with a `data-test` fallback; narrow the mock pattern |
| `element is not visible / not stable / intercepted by another element` | overlay, toast or animation on top | assert the blocker is gone (`toBeHidden`), or wait for the state that removes it — never sleep |
| `Test timeout of 60000ms exceeded` | a missing `await`, a genuinely slow flow, or the app never finished loading | look for un-awaited promises first; they are the most common cause |
| `Unknown fixture "xPage"` | added to a slice's type but not its `extend({})`, or a new slice never merged in `fixtures/index.ts` | run `npx playwright test --list` — it loads the whole graph without a browser |
| Redirected to login / unauthenticated | `e2e/auth/*.json` missing or stale, or the `setup` project failed | `npm run e2e:auth`; delete `e2e/auth/` and let the dependency regenerate it |
| `A snapshot doesn't exist at …-linux.png` | baselines exist only for your platform | generate them in the pinned Docker image — see `playwright-a11y-and-visual` |
| `Timed out waiting 120000ms from config.webServer` | port 4200 already busy, or `npm start` fails to build | run `npm start` by hand and read the compile error |
| Passes alone, fails in the suite | cross-test state — shared fixture data, a leaked `page.route`, a record two tests both mutate | make the data unique per test; see the flake table below |

## Reading a trace

The four tabs, in the order that usually finds the cause:

1. **Network** — did the mocked endpoint actually match? A `page.route` pattern that misses leaves
   the real request in flight and the widget empty. This is the top cause of "element never appeared".
2. **Before / After DOM snapshots** — was the element present but covered (toast, overlay), detached
   by a re-render, or never rendered at all?
3. **Console** — Angular runtime errors and zone.js warnings that broke a binding silently.
4. **Source** — the exact page-object line that fired, so you fix the object rather than the spec.

## Browser Console & Uncaught Exception Monitoring

Catch silent client-side crashes, Angular runtime errors, and broken data bindings during E2E runs.

### Collecting and asserting on uncaught exceptions

```ts
test('should load the home page without client-side exceptions', async ({ page, homePage }, testInfo) => {
  const uncaughtErrors: Error[] = [];
  const consoleMessages: string[] = [];

  page.on('pageerror', (exception) => uncaughtErrors.push(exception));
  page.on('console', (msg) => {
    if (msg.type() === 'error' || msg.type() === 'warning') {
      consoleMessages.push(`[${msg.type()}] ${msg.text()}`);
    }
  });

  // Perform user flows...
  await homePage.visit();

  // Attach diagnostic logs if anything was emitted
  if (consoleMessages.length > 0) {
    await testInfo.attach('browser-console-logs', {
      body: consoleMessages.join('\n'),
      contentType: 'text/plain',
    });
  }

  // Filter expected benign noise (e.g. third-party telemetry / favicon 404s)
  const fatalErrors = uncaughtErrors.filter(
    (err) => !/Failed to load resource.*favicon|ResizeObserver loop/i.test(err.message)
  );

  expect(fatalErrors, 'Verify no unhandled exceptions in browser').toHaveLength(0);
});
```

## Flakiness: root causes and the actual fix

| Cause | Real fix (never a sleep) |
| :-- | :-- |
| Asserting a value read once (`expect(await loc.textContent())`) | use the retrying form: `expect(loc).toHaveText(...)` |
| Acting before the app settled | assert the settled state first (`toBeVisible`, spinner `toBeHidden`) |
| Two tests sharing a record | `generateUserData()` per test, or mock the endpoint |
| Order dependence | move setup into `beforeEach`, through the page object |
| Leftover `page.route` from a previous action | `page.unroute(pattern)` when a test needs the URL back |
| Racing a request | `page.waitForResponse(...)` started **before** the triggering click |
| Animation mid-screenshot | keep `toHaveScreenshot`'s default `animations: 'disabled'` |
| Toast that auto-dismisses | assert it while it exists, or assert the persisted effect instead |
| Counting a `.or()` union with `toHaveCount` | count one unambiguous locator |
| Time-dependent copy ("2 minutes ago") | `mask` it in visuals, or assert a pattern, not the text |

**Reproduce before you fix:** `npx playwright test e2e/specs/<spec>.spec.ts --repeat-each=10 --workers=4`.
If it cannot fail on demand, you cannot know you fixed it. To imitate CI locally,
`CI=1 npx playwright test …` — it switches on retries, 2 workers and the longer expect timeout.

## Policy

1. **Never "fix" a flake with `waitForTimeout` or by raising `retries`.** Retries exist to keep CI
   informative, not to hide a defect. `parseResults.ts` classifies a retry-pass as `flaky`
   precisely so this stays visible.
2. **A flake is a bug in the test or in the app** — decide which before changing anything. Racy
   behaviour the test exposes is often a real product race.
3. **Quarantine visibly, briefly.** `test.fixme(true, 'flaky — <issue link>')` with an owner beats
   a commented-out test or a permanently red pipeline. Anything quarantined without a link is
   deletable.
4. **Fix at the lowest layer.** A locator that keeps breaking belongs in the component object, not
   patched at each call site — and often the real answer is a `data-test` hook in `src/`.
5. **Watch the trend, not the run.** `artifacts/daily-test-metrics.json` and the dashboard
   (`npm run insights:all`) track flaky counts and P95 duration; a spec climbing either list is
   telling you something before it goes red.

