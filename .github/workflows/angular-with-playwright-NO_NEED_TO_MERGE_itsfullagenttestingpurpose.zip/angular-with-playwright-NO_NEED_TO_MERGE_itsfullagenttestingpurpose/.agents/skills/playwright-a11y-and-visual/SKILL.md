---
name: playwright-a11y-and-visual
description: Accessibility and visual-regression testing in this Playwright suite — the checkA11y/makeAxeBuilder fixture, WCAG 2.2 AA rule tags, scoping and rule-disabling policy, plus toHaveScreenshot baselines, the per-project/per-platform snapshotPathTemplate, masking unstable regions, and generating Linux baselines that match CI. Use when writing or fixing an @a11y or @visual spec, when axe reports violations, or when a screenshot comparison fails or a baseline is missing.
---

# Accessibility & Visual Regression

Assertion style is owned by `playwright-locators-and-assertions`; this skill covers only the axe
and screenshot specifics.


Both are "audit" specs: cheap to write, easy to make flaky, and they fail for environment reasons
more often than for product reasons. The rules below exist to keep them trustworthy.

## Accessibility (`@a11y`)

`e2e/fixtures/a11yFixture.ts` provides two fixtures over `@axe-core/playwright`:

```ts
test('should pass WCAG on the Home page', { tag: ['@a11y', '@regression'] },
  async ({ homePage, checkA11y }) => {
    await homePage.visit('/');
    await homePage.verifyHomePageLoaded();   // audit a settled page, never a loading one
    await checkA11y();
  });
```

- `checkA11y()` scans with `wcag2a, wcag2aa, wcag21a, wcag21aa, wcag22aa`, attaches every violation
  to the report as `accessibility-violations` JSON, and asserts `violations` is empty.
- `checkA11y({ context: '[data-test="groupings-modal"]' })` scopes the scan — use it for a dialog
  or a widget so a pre-existing page-level issue doesn't mask your feature's regressions.
- `checkA11y({ disabledRules: ['color-contrast'] })` exists for third-party DOM you cannot fix.
  **Every disabled rule needs a comment naming the reason and the follow-up.** Disabling a rule to
  make a test green is how a suite stops meaning anything.
- `makeAxeBuilder()` is the escape hatch when you need raw `AxeBuilder` chaining
  (`.exclude()`, `.withRules()`, inspecting `results.incomplete`).

Audit *after* the interaction, not only on load — dialogs, expanded menus and error states are
where focus management and ARIA actually break:

```ts
await viewPage.openGroupingsModal();
await checkA11y({ context: '[role="dialog"]' });
```

The project rule (`.claude/CLAUDE.md`) is that the app must pass AXE and meet WCAG AA. When a scan
fails, the fix belongs in `src/` — labels, roles, focus order, contrast — not in the test.

## Visual regression (`@visual`)

```ts
await expect(page).toHaveScreenshot('home-page-layout.png', {
  maxDiffPixelRatio: 0.02,
  threshold: 0.2,
  mask: [
    page.locator('[data-test="live-clock"]'),
    page.locator('.dynamic-pnl-cell'),
  ],
  maskColor: '#FF00FF',
});
```

### Precision visual stability configuration

| Option | Recommended Value | Purpose |
| :-- | :-- | :-- |
| `mask` | `Locator[]` | Overlays dynamic/volatile elements (timers, PnL live feeds, timestamps) with solid color blocks before comparison. |
| `maskColor` | `'#FF00FF'` | Sets custom overlay color for masked regions (magenta makes masked zones distinct in test artifacts). |
| `maxDiffPixelRatio` | `0.01` – `0.05` | Ratio of mismatched pixels allowed (tolerates subtle cross-GPU font antialiasing / sub-pixel raster differences). |
| `threshold` | `0.2` | Per-pixel color tolerance (0 to 1 in YIQ space; 0.2 ignores imperceptible font smoothing variations). |
| `animations` | `'disabled'` | Playwright default: freezes CSS animations and GIF/video frames at frame 0. |

### Component-scoped snapshots

Prefer scoping snapshots to standalone widgets or dialog components rather than full page captures:

```ts
// Localize visual regressions directly to the widget
await expect(cockpitPage.netDeltaKpi.container.root).toHaveScreenshot('kpi-summary-card.png', {
  maxDiffPixelRatio: 0.02,
});
```

### Settle verification before snapshot

Never take a screenshot on an in-flight page or during data transitions:
1. Wait out the loader: `await loaderComponent.waitForFinishLoading();`
2. Assert the payload has painted, not just mounted: `await cockpitPage.riskChartWidget.chart.expectRendered();`
   and `await cockpitPage.pnlTableWidget.grid.expectLoadingHidden();`

### Baselines are per project **and** per platform

`playwright.config.ts` sets:

```ts
snapshotDir: './e2e/snapshots/',
snapshotPathTemplate: '{snapshotDir}/{arg}-{projectName}-{platform}{ext}',
```

so a baseline is `home-page-layout-Chrome-darwin.png`, not a single shared file. Font rasterisation
differs between macOS and Linux; without the template, every CI run would fight every local run.

> **Known gap:** only `-darwin` baselines are committed today, while CI runs `ubuntu-latest`. A
> `@visual` spec in CI will report a missing snapshot until `-linux` baselines are generated and
> committed.

### Generating Linux baselines

Use the Docker image pinned to the **exact** `@playwright/test` version in `package.json`
(currently `1.62.1`) — a mismatched image produces baselines that fail on the next update:

```bash
docker run --rm --network host -v "$(pwd)":/work -w /work \
  mcr.microsoft.com/playwright:v1.62.1-jammy \
  npx playwright test e2e/specs/visual.spec.ts --update-snapshots
```

Locally, `npx playwright test e2e/specs/visual.spec.ts --update-snapshots` refreshes the darwin set.
Commit both. Review the image diff before committing — `--update-snapshots` will happily bless a
real regression.

### Keeping screenshots stable

| Source of noise | Fix |
| :-- | :-- |
| Timestamps, avatars, ids, live counters | `mask: [locator]` (painted over in pink/magenta) |
| Animations, transitions | left to the default `animations: 'disabled'` — don't override it |
| Async content still arriving | assert the page is settled *before* the screenshot |
| Scroll position / lazy images | `fullPage: true`, or screenshot a scoped locator |
| Sub-pixel/AA noise | `maxDiffPixelRatio` (a small ratio, not a large one) |
| A whole widget that is inherently dynamic | screenshot `expect(locator)` instead of `expect(page)` |

Prefer `expect(component.root).toHaveScreenshot()` over full-page shots for feature work: the
smaller the surface, the more precisely a failure points at what changed.

### Reading a failure

The HTML report shows *expected / actual / diff*. Open it with `npm run e2e:report`. If the diff is
a genuine UI change, update the baseline in the same commit as the UI change so review sees both.

