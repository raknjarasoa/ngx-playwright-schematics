---
name: playwright-ci-and-telemetry
description: Running this Playwright suite at scale — the tag taxonomy and the npm scripts it drives, reporter/artifact layout, GitHub Actions workflows with 4-way sharding and blob-report merging, browser binary caching, the auth pre-step, and the insights pipeline (metrics recorder, markdown summary, HTML dashboard, flaky/P95 detection). Use when changing CI workflows, adding a test tag or npm script, configuring reporters or sharding, or interpreting run metrics and artifacts.
---

# CI, Reporting & Telemetry

This skill owns the **tag taxonomy and the npm scripts**. Everything else references it.


## Tags drive everything

| Tag | Meaning | Selected by |
| :-- | :-- | :-- |
| `@smoke` | critical happy path, every PR | `npm run e2e:smoke` |
| `@regression` | full coverage | `--grep @regression` |
| `@ui` | DOM interaction specs | `--grep @ui` |
| `@api` | contract & data lifecycle | `--grep @api` |
| `@contract` | Zod schema conformance | `--grep @contract` |
| `@resilience` | fault / latency injection | `--grep @resilience` |
| `@a11y` | axe WCAG 2.2 AA audits | `--grep @a11y` |
| `@visual` | screenshot regression | `--grep @visual` |
| `@auth` | anything auth-related — session setup, guest opt-out | `--grep @auth` |
| `@setup` | the `auth.setup.ts` storageState writers only | `npm run e2e:auth` (project `setup`) |

Tags go in the test options object, never in the title:

```ts
test('should …', { tag: ['@smoke', '@regression', '@ui'] }, async ({ … }) => { … });
```

Grep composes: `--grep "@smoke|@a11y"`, `--grep-invert @visual`. An untagged test is invisible to
every filtered job — tag on the way in.

## Scripts

| Script | Does |
| :-- | :-- |
| `npm run e2e` | full suite via `ng e2e` (boots the dev server) |
| `npm run e2e:ui` | UI mode — time travel, watch, DOM snapshots |
| `npm run e2e:smoke` | `--grep @smoke` |
| `npm run e2e:a11y` | `--grep @a11y` |
| `npm run e2e:validate` | the 3-stage pre-push gate — see `playwright-architecture` |
| `npm run e2e:scaffold <name>` | generate a feature slice |
| `npm run e2e:trace <path>` | open a recorded trace zip |
| `npm run e2e:codegen` | record against the app, already authenticated |
| `npm run e2e:auth` | `--project=setup` only — regenerates `e2e/auth/*.json` |
| `npm run e2e:report` | opens `artifacts/playwright-report` |
| `npm run allure:report` | generates + opens the Allure report |
| `npm run insights:all` | metrics → markdown summary → HTML dashboard |
| `npm run lint:e2e` | ESLint over `e2e/` (decoupling guardrail) |

Only the two highest-traffic filters have their own script (`e2e:smoke`, `e2e:a11y`); everything
else is `--grep`. Add a script when a filter is run often enough to be worth memorising, not
reflexively for every tag.

> `npm run e2e:auth` selects the **`setup` project**, not the `@auth` tag. Tests tagged `@auth`
> outside that project — the guest opt-out in `api-contract.spec.ts` — are only reached by
> `--grep @auth`. Use the tag to find them; use the script to regenerate session state.

## Reporters & artifacts

Everything lands under `artifacts/` (gitignored):

```
artifacts/
├── playwright-report/          html reporter (open: 'never')
├── allure-results/             allure-playwright, with environmentInfo baked in
├── results.json                json reporter — the input for every insights script
├── junit/test-output-*.xml     junit, embedAnnotationsAsProperties
├── daily-test-metrics.json     appended run history (metrics-recorder)
├── test-insights-report.md     GitHub step summary (markdown-summary)
└── test-dashboard.html         standalone dashboard (html-reporter)
```

Failure evidence is captured only where it pays for itself: `screenshot: 'only-on-failure'`,
`video: 'retain-on-failure'`, `trace: 'on-first-retry'`.

## CI behaviour that differs from local

`playwright.config.ts` keys off `process.env['CI']`: `forbidOnly` (a stray `test.only` fails the
build), `retries: 2`, `workers: 2`, and `expect.timeout` 30s instead of 15s. `webServer` reuses a
running server locally but never in CI.

## The two workflows

**`.github/workflows/e2e.yml`** — single-runner full suite. Checkout → node 22 + npm cache →
`npm ci` → cache `~/.cache/ms-playwright` keyed on `hashFiles('package-lock.json')` → install
browsers on cache miss → **`npm run e2e:auth`** → `npm run e2e` → `npm run insights:all` → upload
`artifacts/`.

**`.github/workflows/e2e-matrix.yml`** — the scaled version:

1. `validate` job: `npm run lint:e2e` + `npm test` (unit) — fails fast before any browser starts.
2. `test` job: `matrix.shardIndex: [1,2,3,4]`, `fail-fast: false`, each shard running
   `npx playwright test --shard=$i/4 --reporter=blob` and uploading `blob-report` under a
   **shard-unique artifact name** (`blob-reports-shard-N`).
3. `merge-reports` job (`if: !cancelled()`): downloads all blobs with
   `pattern: blob-reports-shard-*` + `merge-multiple: true`, then
   `npx playwright merge-reports --reporter html,json,junit all-blobs`, with
   `PLAYWRIGHT_JSON_OUTPUT_NAME` / `PLAYWRIGHT_HTML_REPORT` pointing the merged output back into
   `artifacts/`. Then `npm run insights:all` and
   `cat artifacts/test-insights-report.md >> $GITHUB_STEP_SUMMARY`.

Rules when touching this:

- Blob is the **only** reporter that merges. Per-shard html/json reports cannot be combined.
- Auth runs as its own step *before* the matrix, so credential problems fail loudly instead of as
  dozens of unexplained UI failures.
- Keep `!cancelled()` on the upload and merge steps — a red run is exactly when you need artifacts.
- Changing shard count means changing both `shardIndex` and `shardTotal`.
- Bumping `@playwright/test` invalidates the browser cache key only if `package-lock.json` changes —
  which it does; that is the intent.

## Insights pipeline (`scripts/`)

`scripts/lib/parseResults.ts` is the shared parser over `artifacts/results.json`:

- A test that failed then **passed on retry is classified `flaky`** — pass rate is therefore
  *first-attempt* pass rate, which is the number that matters.
- Exposes `passRate`, `percentile` (P95) and `slowestTests`.

Consumers: `metrics-recorder.ts` (appends a run entry with P95 + top-5 slowest to
`daily-test-metrics.json`), `markdown-summary.ts` (step summary), `html-reporter.ts` (dashboard).
All three exit quietly when `results.json` is absent — never let them fail a build.

Use the output: a spec climbing the slowest-tests list usually means a hidden wait or a missing
mock, and a rising flaky count is a regression in test design, not bad luck. Take it to
`playwright-debug-and-flake`.
