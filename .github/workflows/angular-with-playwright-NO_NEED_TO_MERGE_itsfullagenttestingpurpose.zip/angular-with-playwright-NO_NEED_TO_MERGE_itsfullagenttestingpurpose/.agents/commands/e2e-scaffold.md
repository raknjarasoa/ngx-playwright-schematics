---
name: e2e-scaffold
description: Scaffolds a new Playwright E2E feature slice (Route -> Component Object -> Page Object -> Fixtures -> Spec) following the enterprise architecture.
parameters:
  - name: featureName
    description: The name of the feature to scaffold (e.g., 'userProfile', 'pnlBlotter', 'riskMatrix').
    required: true
  - name: flags
    description: Optional CLI flags like '--panel' / '--no-dialog' for standalone widgets or '--overwrite' to replace existing files.
    required: false
---

# `/e2e-scaffold` Command

Execute the automated scaffolding workflow to generate a new end-to-end feature test suite.

## Instructions

1. Identify the target feature name from the user's input: `{{featureName}}`.
2. Run the automated scaffolder CLI:
   ```bash
   # Standard modal dialog feature
   npm run e2e:scaffold {{featureName}}

   # Standalone widget / panel / chart / grid (non-dialog)
   npm run e2e:scaffold {{featureName}} -- --panel
   ```
3. Inspect the newly created or updated files:
   - Component Object: `e2e/components/<feature>.component.ts` (composes `ModalComponent` by default, or standalone with `--panel`)
   - Page Object: `e2e/pages/<feature>Page.ts` (owns the embedded component)
   - Route registration: `e2e/pages/routes.ts`
   - Fixture injection: `e2e/fixtures/pageFixtures.ts`
   - Test Spec: `e2e/specs/<feature>.spec.ts`
4. Run validation checks to ensure zero syntax, decoupling, or typing regressions:
   ```bash
   npm run e2e:validate
   ```
5. Present the generated files and instructions on how to customize locators and run tests with:
   ```bash
   npx playwright test e2e/specs/<feature>.spec.ts --ui
   ```
