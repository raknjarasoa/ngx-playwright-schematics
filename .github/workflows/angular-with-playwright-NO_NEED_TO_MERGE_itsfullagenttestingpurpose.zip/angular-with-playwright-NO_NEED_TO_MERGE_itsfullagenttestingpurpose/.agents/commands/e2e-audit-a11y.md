---
name: e2e-audit-a11y
description: Runs automated WCAG 2.2 AA accessibility audits using @axe-core/playwright and reports any compliance violations.
---

# `/e2e-audit-a11y` Command

Audit web pages for WCAG 2.2 AA accessibility violations using the pre-configured `a11yFixture` (`@axe-core/playwright`).

## Instructions

1. Run the dedicated accessibility test suite:
   ```bash
   npm run e2e:a11y
   ```
2. If violations are found:
   - Open the `accessibility-violations` JSON attachment on the failing test in the HTML report (`npm run e2e:report`); `a11yFixture` attaches it via `testInfo.attach`.
   - Categorize violations by impact (`critical`, `serious`, `moderate`, `minor`).
   - Identify missing ARIA attributes (`aria-label`, `aria-expanded`, `aria-sort`), contrast issues, or semantic HTML defects.
3. Suggest the exact HTML / Angular component template fixes in `src/` to resolve accessibility violations without weakening test rules.
