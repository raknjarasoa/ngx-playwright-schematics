---
name: e2e-insights
description: Executes tests, records execution metrics (P95, flakiness, duration), and generates markdown summary + interactive HTML dashboard.
---

# `/e2e-insights` Command

Run the complete E2E telemetry pipeline to collect performance metrics, detect flaky specs, and render dashboards.

## Instructions

1. Execute the telemetry pipeline:
   ```bash
   npm run insights:all
   ```
2. The pipeline executes three automated stages:
   - `scripts/metrics-recorder.ts`: Parses `artifacts/results.json`, calculates P95 execution duration, detects flaky retries, and writes to `artifacts/daily-test-metrics.json`.
   - `scripts/markdown-summary.ts`: Renders executive summary to `artifacts/test-insights-report.md`.
   - `scripts/html-reporter.ts`: Builds interactive visual dashboard to `artifacts/test-dashboard.html`.
3. Present the summary table (total tests, passed, flaky on retry, failed, P95 duration) and point the user to the generated reports in `artifacts/`.
