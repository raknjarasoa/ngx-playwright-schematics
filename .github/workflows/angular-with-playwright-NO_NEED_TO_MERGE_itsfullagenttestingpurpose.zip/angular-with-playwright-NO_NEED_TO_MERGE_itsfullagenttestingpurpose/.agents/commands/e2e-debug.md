---
name: e2e-debug
description: Launches Playwright interactive debugging mode with time-travel, DOM inspector, trace viewer, and live locator picker.
parameters:
  - name: specPath
    description: Optional path to a specific spec file to debug (e.g. 'e2e/specs/view-groupings.spec.ts').
    required: false
---

# `/e2e-debug` Command

Launch Playwright in interactive UI, Inspector, or Trace Viewer mode.

## Instructions

1. If a specific spec is provided (`{{specPath}}`), launch interactive UI mode:
   ```bash
   npx playwright test {{specPath}} --ui
   ```
2. If no spec is specified, open the full interactive UI test runner:
   ```bash
   npm run e2e:ui
   ```
3. For step-by-step debugging with the Playwright Inspector window and live console:
   ```bash
   npx playwright test {{specPath}} --debug
   ```
4. For post-mortem analysis of recorded trace zips from failed local or CI runs:
   ```bash
   # Open specific trace file
   npx playwright show-trace test-results/<test-dir>/trace.zip

   # Or via the npm script — it still needs the path
   npm run e2e:trace test-results/<test-dir>/trace.zip
   ```
   Inspect the DOM snapshots, network waterfall, console logs, and action filmstrip to identify root causes.
