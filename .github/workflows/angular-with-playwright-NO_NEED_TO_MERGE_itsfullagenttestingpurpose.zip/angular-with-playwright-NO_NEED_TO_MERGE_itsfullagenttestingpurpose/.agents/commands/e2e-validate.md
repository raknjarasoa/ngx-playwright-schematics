---
name: e2e-validate
description: Runs the 3-step pre-push quality gate sequence (ESLint decoupling, TypeScript types, and Playwright test graph resolution).
---

# `/e2e-validate` Command

Execute the complete pre-push architecture validation suite to guarantee test suite health and decoupling integrity.

## Instructions

1. Execute the validation command:
   ```bash
   npm run e2e:validate
   ```
2. The command performs three sequential checks:
   - **Stage 1 (`npx eslint e2e`)**: Verifies strict black-box decoupling by blocking any forbidden imports from `src/` inside `e2e/`.
   - **Stage 2 (`npx tsc -p e2e/tsconfig.json --noEmit`)**: Verifies strict TypeScript compilation and resolves all path aliases (`@components/*`, `@pages/*`, `@fixtures/*`, `@helpers/*`, `@global/*`, `@specs/*`).
   - **Stage 3 (`npx playwright test --list`)**: Validates fixture dependency injection graphs (`mergeTests`), discovers all specs, and checks for circular dependencies without launching browsers.
3. If errors are detected, classify and fix immediately:
   - **Illegal import from `src/`**: Remove the `src/` import; use black-box API contracts or DOM locators.
   - **Broken TypeScript alias / missing export**: Check `e2e/tsconfig.json` path mappings and verify named exports.
   - **Fixture / DI graph error**: Check fixture slices in `@fixtures/index` and verify fixture parameters match registrations.
4. If successful, confirm that the E2E suite is ready for CI or PR submission.
