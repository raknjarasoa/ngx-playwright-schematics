# 🚀 Angular with Playwright

Production-grade Angular 21 starter repository featuring standalone components, Tailwind CSS v4, Vitest unit testing, and an enterprise Playwright E2E automation architecture at scale.

---

## ⚡ Quickstart

```bash
# Install dependencies
npm install

# Install Playwright browser binaries
npx playwright install --with-deps

# Start local Angular development server (http://localhost:4200)
npm start
```

---

## 📦 Angular Schematics Automation

This workspace includes a custom Angular Schematic (`schematics/`) to automatically scaffold and wire the complete Playwright E2E Architecture into any Angular project.

```bash
# Build the schematics package
npm run build:schematics

# Run schematic on an existing Angular project
ng g ./schematics:ng-add

# Or with options:
ng g ./schematics:ng-add --project=my-app --installBrowsers=true --overwrite=true
```

### What the Schematic Scaffolds:
1. **Playwright Config**: `playwright.config.ts` (snapshots, reporters, webServer, storageState, multi-browser).
2. **Architecture Structure**: Full `e2e/` folder with Component Objects, Fixture Slices (`mergeTests`), Helpers, Page Objects, and Setup/Specs.
3. **HTTP Contract Interceptor**: `src/app/core/interceptors/api-contract.interceptor.ts` with runtime Zod drift validation.
4. **Telemetry Scripts**: `scripts/` (metrics recorder, HTML dashboard, markdown report generator).
5. **CI Workflows**: `.github/workflows/e2e.yml` and sharded `e2e-matrix.yml`.
6. **Tooling Integration**: Configures `angular.json` (`architect.e2e` builder and schematic collections), `package.json` (scripts & dependencies), `.gitignore`, and `eslint.config.mjs` (E2E decoupling guardrail).
7. **Graceful Conflict Handling**: Safely merges package scripts, dependencies, angular configurations, and resolves file conflicts without aborting.

---

## 🛠️ Command Reference

| Script | Command | Purpose |
| :-- | :-- | :-- |
| `npm run e2e:validate` | `eslint && tsc --noEmit && playwright test --list` | **Pre-push gate.** Decoupling, types, and fixture/POM wiring. No dev server needed. |
| `npm run e2e:scaffold <name>` | `tsx scripts/scaffold-feature.ts` | Generate a feature slice (route → component → page → fixture → spec). `--panel` for non-dialog widgets. |
| `npm run e2e` | `ng e2e` | Full suite headless (auto-starts the dev server). |
| `npm run e2e:ui` | `playwright test --ui` | Interactive UI mode — time travel, DOM snapshots, watch. |
| `npm run e2e:smoke` | `playwright test --grep @smoke` | Fast smoke suite for PR feedback. |
| `npm run e2e:a11y` | `playwright test --grep @a11y` | axe WCAG 2.2 AA audits. |
| `npm run e2e:auth` | `playwright test --project=setup` | Regenerate `e2e/auth/*.json` session state. |
| `npm run e2e:codegen` | `playwright codegen …` | Record against the app, already authenticated. |
| `npm run e2e:trace <path>` | `playwright show-trace` | Open a recorded trace zip. |
| `npm run e2e:report` | `playwright show-report artifacts/playwright-report` | Open the HTML report. |
| `npm run allure:report` | `allure generate && allure open` | Generate and open the Allure report. |
| `npm run insights:all` | `tsx scripts/…` | Run metrics → markdown summary → HTML dashboard. |
| `npm run lint` | `npx eslint src scripts e2e` | Lint everything, including the E2E decoupling check. |
| `npm test` | `ng test` | Vitest unit suite. |
| `npm run build:schematics` | `tsx … && tsc && tsx …` | Sync blueprint templates and build the schematic. |


---

## 🧪 E2E Architecture

The suite under `e2e/` is a black-box consumer of the app: nothing in `e2e/` imports from `src/`
(enforced by `no-restricted-imports` in `eslint.config.mjs`).

```
e2e/
├── components/   Component & widget objects — the only place selectors are written
├── pages/        Page objects + the `routes.ts` URL registry
├── fixtures/     7 mergeTests slices, composed in fixtures/index.ts
├── helpers/      APIClient, financial parsers, utilities
├── global/       global setup / teardown
├── specs/        the tests — import { test, expect } from '@fixtures/index'
└── snapshots/    visual baselines, per project and per platform
```

Path aliases (`e2e/tsconfig.json`): `@components/* @pages/* @fixtures/* @helpers/* @global/*
@specs/*`.

**The rules, the skill index, and the day-to-day workflow live in [`AGENTS.md`](./AGENTS.md).**
Detailed, task-specific guidance lives in `.agents/skills/` — eleven skills covering architecture,
page objects, locators, fixtures & auth, data mocking, a11y & visual, CI & telemetry, debugging,
test generation, and the schematic.
