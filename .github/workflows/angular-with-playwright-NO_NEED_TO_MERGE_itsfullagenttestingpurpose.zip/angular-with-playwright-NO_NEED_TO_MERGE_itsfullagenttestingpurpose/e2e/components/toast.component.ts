import { Locator, Page, expect, test } from '@playwright/test';

/**
 * Global Toast Component Object.
 */
export class ToastComponent {
  readonly root: Locator;
  readonly message: Locator;

  constructor(page: Page, rootLocator?: Locator) {
    this.root =
      rootLocator ??
      page
        .getByRole('alert')
        .or(page.locator('.toast, .alert, .notification, [data-test="toast-notification"]'));

    this.message = this.root.locator('.toast-message, .alert-message, p, span').first();
  }

  async expectMessage(textPattern: string | RegExp): Promise<void> {
    await test.step(`Verify toast message contains "${textPattern}"`, async () => {
      await expect(this.root).toBeVisible();
      await expect(this.root).toContainText(textPattern);
    });
  }

  async verifyNoFatalErrors(): Promise<void> {
    await test.step('Verify no fatal error toast is displayed', async () => {
      const errorToast = this.root.filter({ hasText: /fatal|exception|crash|internal error/i });
      await expect(errorToast).toHaveCount(0);
    });
  }
}
