import { Locator, Page, expect, test } from '@playwright/test';

/**
 * Generic Modal shell component object.
 * Encapsulates modal dialog chrome: backdrop, title, and close control.
 */
export class ModalComponent {
  readonly page: Page;
  readonly root: Locator;
  readonly title: Locator;
  readonly closeButton: Locator;

  constructor(page: Page, rootLocator?: Locator) {
    this.page = page;
    this.root =
      rootLocator ??
      page
        .getByRole('dialog')
        .or(page.locator('.modal, [role="dialog"], [data-test="modal-container"]'));

    this.title = this.root
      .getByRole('heading')
      .or(this.root.locator('.modal-title, [data-test="modal-title"]'));

    this.closeButton = this.root
      .getByRole('button', { name: /close|fermer|dismiss/i })
      .or(this.root.locator('.close, [data-test="modal-close-btn"], button[data-dismiss="modal"]'));
  }

  async expectOpen(): Promise<void> {
    await test.step('Verify modal dialog is visible', async () => {
      await expect(this.root).toBeVisible();
    });
  }

  async expectClosed(): Promise<void> {
    await test.step('Verify modal dialog is closed / hidden', async () => {
      await expect(this.root).toBeHidden();
    });
  }

  async close(): Promise<void> {
    await test.step('Close modal dialog', async () => {
      await this.closeButton.click();
      await this.expectClosed();
    });
  }
}
