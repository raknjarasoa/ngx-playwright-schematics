import { Locator, Page, expect, test } from '@playwright/test';

/**
 * Global Header Component Object.
 * Encapsulates navigation links, branding, and logged-in user state.
 */
export class HeaderComponent {
  readonly root: Locator;
  readonly homeLink: Locator;
  readonly productsLink: Locator;
  readonly cartLink: Locator;
  readonly signupLoginLink: Locator;
  readonly logoutLink: Locator;
  readonly deleteAccountLink: Locator;
  readonly testCasesLink: Locator;
  readonly contactUsLink: Locator;
  readonly loggedInUserDisplay: Locator;

  constructor(page: Page, rootLocator?: Locator) {
    this.root = rootLocator ?? page.locator('header#header');

    this.homeLink = this.root.locator('a[href="/"]').first();
    this.productsLink = this.root.locator('a[href="/products"]');
    this.cartLink = this.root.locator('a[href="/view_cart"]');
    this.signupLoginLink = this.root.locator('a[href="/login"]');
    this.logoutLink = this.root.locator('a[href="/logout"]');
    this.deleteAccountLink = this.root.locator('a[href="/delete_account"]');
    this.testCasesLink = this.root.locator('a[href="/test_cases"]');
    this.contactUsLink = this.root.locator('a[href="/contact_us"]');

    this.loggedInUserDisplay = this.root.locator('li').filter({ hasText: /logged in as/i });
  }

  async expectVisible(): Promise<void> {
    await test.step('Verify navigation header is visible', async () => {
      await expect(this.root).toBeVisible();
    });
  }

  async clickSignupLogin(): Promise<void> {
    await test.step('Click "Signup / Login" link in header', async () => {
      await this.signupLoginLink.click();
    });
  }

  async clickDeleteAccount(): Promise<void> {
    await test.step('Click "Delete Account" link in header', async () => {
      await this.deleteAccountLink.click();
    });
  }

  async clickLogout(): Promise<void> {
    await test.step('Click "Logout" link in header', async () => {
      await this.logoutLink.click();
    });
  }

  async expectLoggedInAs(username: string): Promise<void> {
    await test.step(`Verify header shows "Logged in as ${username}"`, async () => {
      await expect(this.loggedInUserDisplay).toBeVisible();
      await expect(this.loggedInUserDisplay).toContainText(`Logged in as ${username}`);
    });
  }

  async expectLoggedOut(): Promise<void> {
    await test.step('Verify header shows unauthenticated Signup/Login state', async () => {
      await expect(this.signupLoginLink).toBeVisible();
      await expect(this.loggedInUserDisplay).toHaveCount(0);
    });
  }
}
