import { Locator, Page, expect, test } from '@playwright/test';

/**
 * Global Loader Component Object.
 */
export class LoaderComponent {
  readonly root: Locator;

  constructor(page: Page, rootLocator?: Locator) {
    this.root =
      rootLocator ??
      page
        .getByRole('progressbar')
        .or(page.locator('.spinner, .loader, .loading-indicator, [data-test="global-loader"]'));
  }

  async expectVisible(): Promise<void> {
    await test.step('Verify loading indicator is visible', async () => {
      await expect(this.root).toBeVisible();
    });
  }

  async expectHidden(): Promise<void> {
    await test.step('Verify loading indicator is hidden', async () => {
      await expect(this.root).toBeHidden();
    });
  }
}
