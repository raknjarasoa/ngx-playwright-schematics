import { test as setup } from '@playwright/test';
import { CredsManager } from '@fixtures/creds';
import { APIClient } from '@helpers/apiClient';
import { join } from 'path';

const authDir = join(process.cwd(), 'e2e', 'auth');

setup.describe('Authentication Setup', () => {
  setup(
    'authenticate default user persona',
    { tag: ['@auth', '@setup'] },
    async ({ page }) => {
      const creds = CredsManager.getCredentials('default');
      const api = new APIClient(page);
      await api.performAPILogin(creds);
      await page.context().storageState({ path: join(authDir, 'default.json') });
    }
  );

  setup(
    'authenticate admin user persona',
    { tag: ['@auth', '@setup'] },
    async ({ page }) => {
      const creds = CredsManager.getCredentials('admin');
      const api = new APIClient(page);
      await api.performAPILogin(creds);
      await page.context().storageState({ path: join(authDir, 'admin.json') });
    }
  );

  setup(
    'authenticate guest user persona',
    { tag: ['@auth', '@setup'] },
    async ({ page }) => {
      const creds = CredsManager.getCredentials('guest');
      const api = new APIClient(page);
      await api.performAPILogin(creds);
      await page.context().storageState({ path: join(authDir, 'guest.json') });
    }
  );
});
