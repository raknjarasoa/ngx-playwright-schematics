import { test, expect } from '@fixtures/index';

test.describe('User Registration Specification', () => {
  // Test Case 1 is an unauthenticated registration journey: explicitly opt out of pre-cached storageState
  test.use({ storageState: { cookies: [], origins: [] } });

  test(
    'Test Case 1: Register User with complete account details and delete account',
    {
      tag: ['@smoke', '@regression', '@ui', '@auth'],
    },
    async ({
      homePage,
      loginSignupPage,
      signupAccountPage,
      accountCreatedPage,
      accountDeletedPage,
      createdUser,
    }) => {
      // 1 & 2. Launch browser & Navigate to url 'http://automationexercise.com'
      await homePage.visit();

      // 3. Verify that home page is visible successfully
      await homePage.verifyHomePageVisible();

      // 4. Click on 'Signup / Login' button
      await homePage.header.clickSignupLogin();

      // 5. Verify 'New User Signup!' is visible
      await loginSignupPage.verifyNewUserSignupVisible();

      // 6 & 7. Enter name and email address, then click 'Signup' button
      await loginSignupPage.submitSignup(createdUser.name, createdUser.email);

      // 8. Verify that 'ENTER ACCOUNT INFORMATION' is visible
      await signupAccountPage.verifyEnterAccountInformationVisible();

      // 9. Fill details: Title, Password, Date of birth
      await signupAccountPage.fillAccountDetails(createdUser);

      // 10. Select checkbox 'Sign up for our newsletter!'
      await signupAccountPage.selectNewsletter();

      // 11. Select checkbox 'Receive special offers from our partners!'
      await signupAccountPage.selectSpecialOffers();

      // 12. Fill details: First name, Last name, Company, Address, Address2, Country, State, City, Zipcode, Mobile Number
      await signupAccountPage.fillAddressDetails(createdUser);

      // 13. Click 'Create Account button'
      await signupAccountPage.clickCreateAccount();

      // 14. Verify that 'ACCOUNT CREATED!' is visible
      await accountCreatedPage.verifyAccountCreatedVisible();

      // 15. Click 'Continue' button
      await accountCreatedPage.clickContinue();

      // 16. Verify that 'Logged in as username' is visible
      await homePage.header.expectLoggedInAs(createdUser.name);

      // 17. Click 'Delete Account' button
      await homePage.header.clickDeleteAccount();

      // 18. Verify that 'ACCOUNT DELETED!' is visible and click 'Continue' button
      await accountDeletedPage.verifyAccountDeletedVisible();
      await accountDeletedPage.clickContinue();

      // Final verification: user is redirected back to home page in unauthenticated state
      await homePage.verifyHomePageVisible();
    }
  );
});
