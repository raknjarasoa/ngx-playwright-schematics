import { Page, test } from '@playwright/test';

/**
 * Utility helper functions for E2E tests.
 */
export class TestUtils {
  /**
   * Generates a unique email address with a prefix and timestamp.
   */
  static generateUniqueEmail(prefix = 'testuser'): string {
    const timestamp = Date.now();
    const randomSuffix = Math.floor(Math.random() * 10_000);
    return `${prefix}_${timestamp}_${randomSuffix}@example.com`;
  }

  /**
   * Generates a random alphanumeric string.
   */
  static randomString(length = 8): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  /**
   * Intercepts and blocks third-party advertising, trackers, and popup scripts that
   * can inject iframe overlays (such as Google Vignette ads) during tests.
   */
  static async suppressAdsAndTrackers(page: Page): Promise<void> {
    await test.step('Route mocking: block third-party ad networks and trackers', async () => {
      await page.route(
        /(\.google-analytics\.com|\.googletagservices\.com|\.googlesyndication\.com|doubleclick\.net|admaster\.cc|criteo\.com|adnxs\.com)/,
        async (route) => {
          await route.abort();
        }
      );
    });
  }
}
