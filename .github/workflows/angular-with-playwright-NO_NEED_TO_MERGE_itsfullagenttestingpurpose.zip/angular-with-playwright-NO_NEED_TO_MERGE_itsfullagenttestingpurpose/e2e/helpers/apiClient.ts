import { Page, APIRequestContext, request } from '@playwright/test';
import { z } from 'zod';
import { UserCredentials } from '@fixtures/creds';

/**
 * Zod schema validating user authentication and API response contract.
 */
export const AuthResponseContract = z.object({
  responseCode: z.number().optional(),
  message: z.string().optional(),
});

export type AuthResponse = z.infer<typeof AuthResponseContract>;

/**
 * APIClient handles backend interactions, contract validation via Zod, and auth state seeding.
 */
export class APIClient {
  private page?: Page;
  private requestContext?: APIRequestContext;

  constructor(page?: Page) {
    this.page = page;
  }

  private async getRequestContext(): Promise<APIRequestContext> {
    if (this.page) {
      return this.page.request;
    }
    if (!this.requestContext) {
      this.requestContext = await request.newContext();
    }
    return this.requestContext;
  }

  /**
   * Performs an API login or sets up the session state for authentication.
   */
  async performAPILogin(creds: UserCredentials): Promise<void> {
    if (!this.page) {
      throw new Error('APIClient.performAPILogin requires a Page instance to seed browser storage state.');
    }

    // Seed mock/real session info in localStorage for pre-cached storageState
    await this.page.addInitScript((userData) => {
      window.localStorage.setItem('user_session', JSON.stringify(userData));
      window.localStorage.setItem('auth_token', 'mock_jwt_token_for_playwright_e2e');
    }, { email: creds.email, name: creds.name ?? 'Default User' });
  }

  /**
   * Validates API responses against a Zod contract.
   */
  async validateResponseContract<T>(schema: z.ZodType<T>, data: unknown, strict = true): Promise<T | null> {
    if (strict) {
      return schema.parse(data);
    }
    const result = schema.safeParse(data);
    if (!result.success) {
      console.warn('API Contract Drift Warning:', result.error.format());
      return null;
    }
    return result.data;
  }

  /**
   * Releases owned API request context if created standalone.
   */
  async dispose(): Promise<void> {
    if (this.requestContext) {
      await this.requestContext.dispose();
      this.requestContext = undefined;
    }
  }
}
