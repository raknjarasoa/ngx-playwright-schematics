import { Locator, Page, expect, test } from '@playwright/test';
import { Routes } from '@pages/routes';
import { UserRegistrationData } from '@fixtures/dataFactoryFixture';
import { TestUtils } from '@helpers/utils';

/**
 * Page Object for Account Information & Address registration screen ('/signup').
 */
export class SignupAccountPage {
  private readonly page: Page;
  readonly routes: Routes;

  // Account Information
  readonly enterAccountInfoHeading: Locator;
  readonly titleMrRadio: Locator;
  readonly titleMrsRadio: Locator;
  readonly nameInput: Locator;
  readonly emailInput: Locator;
  readonly passwordInput: Locator;
  readonly daysSelect: Locator;
  readonly monthsSelect: Locator;
  readonly yearsSelect: Locator;
  readonly newsletterCheckbox: Locator;
  readonly specialOffersCheckbox: Locator;

  // Address Information
  readonly addressInfoHeading: Locator;
  readonly firstNameInput: Locator;
  readonly lastNameInput: Locator;
  readonly companyInput: Locator;
  readonly addressInput: Locator;
  readonly address2Input: Locator;
  readonly countrySelect: Locator;
  readonly stateInput: Locator;
  readonly cityInput: Locator;
  readonly zipcodeInput: Locator;
  readonly mobileNumberInput: Locator;
  readonly createAccountButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.routes = new Routes(page);

    this.enterAccountInfoHeading = this.page
      .getByRole('heading', { name: /enter account information/i })
      .or(this.page.locator('.login-form h2:has-text("Enter Account Information")'));

    this.titleMrRadio = this.page.locator('#id_gender1, input[value="Mr"]');
    this.titleMrsRadio = this.page.locator('#id_gender2, input[value="Mrs"]');

    this.nameInput = this.page.locator('input[data-qa="name"], #name');
    this.emailInput = this.page.locator('input[data-qa="email"], #email');
    this.passwordInput = this.page.locator('input[data-qa="password"], #password');

    this.daysSelect = this.page.locator('select[data-qa="days"], #days');
    this.monthsSelect = this.page.locator('select[data-qa="months"], #months');
    this.yearsSelect = this.page.locator('select[data-qa="years"], #years');

    this.newsletterCheckbox = this.page.locator('#newsletter, input[name="newsletter"]');
    this.specialOffersCheckbox = this.page.locator('#optin, input[name="optin"]');

    this.addressInfoHeading = this.page
      .getByRole('heading', { name: /address information/i })
      .or(this.page.locator('.login-form h2:has-text("Address Information")'));

    this.firstNameInput = this.page.locator('input[data-qa="first_name"], #first_name');
    this.lastNameInput = this.page.locator('input[data-qa="last_name"], #last_name');
    this.companyInput = this.page.locator('input[data-qa="company"], #company');
    this.addressInput = this.page.locator('input[data-qa="address"], #address1');
    this.address2Input = this.page.locator('input[data-qa="address2"], #address2');
    this.countrySelect = this.page.locator('select[data-qa="country"], #country');
    this.stateInput = this.page.locator('input[data-qa="state"], #state');
    this.cityInput = this.page.locator('input[data-qa="city"], #city');
    this.zipcodeInput = this.page.locator('input[data-qa="zipcode"], #zipcode');
    this.mobileNumberInput = this.page.locator('input[data-qa="mobile_number"], #mobile_number');
    this.createAccountButton = this.page.locator('button[data-qa="create-account"]');
  }

  async verifyEnterAccountInformationVisible(): Promise<void> {
    await test.step('Verify that "ENTER ACCOUNT INFORMATION" is visible', async () => {
      await expect(this.enterAccountInfoHeading).toBeVisible();
    });
  }

  async fillAccountDetails(data: Pick<UserRegistrationData, 'title' | 'password' | 'dob'>): Promise<void> {
    await test.step('Fill details: Title, Password, Date of birth', async () => {
      if (data.title === 'Mrs') {
        await this.titleMrsRadio.check({ force: true });
      } else {
        await this.titleMrRadio.check({ force: true });
      }

      await this.passwordInput.fill(data.password);
      await this.daysSelect.selectOption(data.dob.day);
      await this.monthsSelect.selectOption(data.dob.month);
      await this.yearsSelect.selectOption(data.dob.year);
    });
  }

  async selectNewsletter(): Promise<void> {
    await test.step('Select checkbox "Sign up for our newsletter!"', async () => {
      await this.newsletterCheckbox.check({ force: true });
    });
  }

  async selectSpecialOffers(): Promise<void> {
    await test.step('Select checkbox "Receive special offers from our partners!"', async () => {
      await this.specialOffersCheckbox.check({ force: true });
    });
  }

  async fillAddressDetails(
    data: Pick<
      UserRegistrationData,
      | 'firstName'
      | 'lastName'
      | 'company'
      | 'address'
      | 'address2'
      | 'country'
      | 'state'
      | 'city'
      | 'zipcode'
      | 'mobileNumber'
    >
  ): Promise<void> {
    await test.step('Fill address details: First name, Last name, Company, Address, Country, State, City, Zipcode, Mobile Number', async () => {
      await this.firstNameInput.fill(data.firstName);
      await this.lastNameInput.fill(data.lastName);
      await this.companyInput.fill(data.company);
      await this.addressInput.fill(data.address);
      await this.address2Input.fill(data.address2);
      await this.countrySelect.selectOption(data.country);
      await this.stateInput.fill(data.state);
      await this.cityInput.fill(data.city);
      await this.zipcodeInput.fill(data.zipcode);
      await this.mobileNumberInput.fill(data.mobileNumber);
    });
  }

  async clickCreateAccount(): Promise<void> {
    await test.step('Click "Create Account" button', async () => {
      await this.createAccountButton.click({ force: true });
      await this.page.waitForLoadState('domcontentloaded');
    });
  }

  async fillAndSubmitRegistration(userData: UserRegistrationData): Promise<void> {
    await this.fillAccountDetails(userData);
    if (userData.newsletter) {
      await this.selectNewsletter();
    }
    if (userData.specialOffers) {
      await this.selectSpecialOffers();
    }
    await this.fillAddressDetails(userData);
    await this.clickCreateAccount();
  }
}
