import { Locator, Page, expect, test } from '@playwright/test';
import { Routes } from '@pages/routes';

/**
 * Page Object for Account Deleted confirmation screen ('/delete_account').
 */
export class AccountDeletedPage {
  private readonly page: Page;
  readonly routes: Routes;
  readonly accountDeletedHeading: Locator;
  readonly continueButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.routes = new Routes(page);

    this.accountDeletedHeading = this.page
      .getByRole('heading', { name: /account deleted!/i })
      .or(this.page.locator('h2[data-qa="account-deleted"], .login-form h2:has-text("Account Deleted!")'));

    this.continueButton = this.page
      .locator('[data-qa="continue-button"]')
      .or(this.page.getByRole('link', { name: /continue/i }));
  }

  async verifyAccountDeletedVisible(): Promise<void> {
    await test.step('Verify that "ACCOUNT DELETED!" is visible', async () => {
      await expect(this.accountDeletedHeading).toBeVisible();
    });
  }

  async clickContinue(): Promise<void> {
    await test.step('Click "Continue" button on Account Deleted page', async () => {
      await this.continueButton.click({ force: true });
      await this.page.waitForLoadState('domcontentloaded');
    });
  }
}
