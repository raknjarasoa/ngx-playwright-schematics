import { Locator, Page, expect, test } from '@playwright/test';
import { Routes } from '@pages/routes';
import { HeaderComponent } from '@components/header.component';
import { TestUtils } from '@helpers/utils';

/**
 * Page Object for the Home screen ('/').
 */
export class HomePage {
  private readonly page: Page;
  readonly routes: Routes;
  readonly header: HeaderComponent;
  readonly logo: Locator;
  readonly sliderCarousel: Locator;
  readonly featuresItemsHeading: Locator;

  constructor(page: Page) {
    this.page = page;
    this.routes = new Routes(page);
    this.header = new HeaderComponent(page);

    this.logo = this.page
      .locator('.logo img, [alt*="Automation Exercise"], [alt*="Website for automation practice"]')
      .first();

    this.sliderCarousel = this.page
      .locator('#slider, #slider-carousel, .carousel')
      .first();

    this.featuresItemsHeading = this.page
      .getByRole('heading', { name: /features items/i })
      .or(this.page.locator('.features_items h2.title'));
  }

  async visit(path = '/'): Promise<void> {
    await test.step(`Navigate to Home page (${path})`, async () => {
      await TestUtils.suppressAdsAndTrackers(this.page);
      await this.page.goto(path);
      await this.page.waitForLoadState('domcontentloaded');
    });
  }

  async verifyHomePageVisible(): Promise<void> {
    await test.step('Verify that home page is visible successfully', async () => {
      await expect(this.page).toHaveTitle(/Automation Exercise/i);
      await expect(this.header.root).toBeVisible();
      await expect(this.header.homeLink).toBeVisible();
    });
  }
}
