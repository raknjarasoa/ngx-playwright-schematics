import { Locator, Page, expect, test } from '@playwright/test';
import { Routes } from '@pages/routes';

/**
 * Page Object for Account Created confirmation screen ('/account_created').
 */
export class AccountCreatedPage {
  private readonly page: Page;
  readonly routes: Routes;
  readonly accountCreatedHeading: Locator;
  readonly continueButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.routes = new Routes(page);

    this.accountCreatedHeading = this.page
      .getByRole('heading', { name: /account created!/i })
      .or(this.page.locator('h2[data-qa="account-created"], .login-form h2:has-text("Account Created!")'));

    this.continueButton = this.page
      .locator('[data-qa="continue-button"]')
      .or(this.page.getByRole('link', { name: /continue/i }));
  }

  async verifyAccountCreatedVisible(): Promise<void> {
    await test.step('Verify that "ACCOUNT CREATED!" is visible', async () => {
      await expect(this.accountCreatedHeading).toBeVisible();
    });
  }

  async clickContinue(): Promise<void> {
    await test.step('Click "Continue" button', async () => {
      await this.continueButton.click({ force: true });
      await this.page.waitForLoadState('domcontentloaded');
    });
  }
}
