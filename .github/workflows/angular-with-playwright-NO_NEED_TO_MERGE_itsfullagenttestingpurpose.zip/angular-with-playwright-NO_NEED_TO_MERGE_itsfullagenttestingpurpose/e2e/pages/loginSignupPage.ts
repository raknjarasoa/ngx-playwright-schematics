import { Locator, Page, expect, test } from '@playwright/test';
import { Routes } from '@pages/routes';
import { HeaderComponent } from '@components/header.component';
import { CONSTANTS } from '@fixtures/constants';
import { TestUtils } from '@helpers/utils';

/**
 * Page Object for Signup & Login screen ('/login').
 */
export class LoginSignupPage {
  private readonly page: Page;
  readonly routes: Routes;
  readonly header: HeaderComponent;

  // New User Signup locators
  readonly signupHeading: Locator;
  readonly signupNameInput: Locator;
  readonly signupEmailInput: Locator;
  readonly signupButton: Locator;

  // Login to account locators
  readonly loginHeading: Locator;
  readonly loginEmailInput: Locator;
  readonly loginPasswordInput: Locator;
  readonly loginButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.routes = new Routes(page);
    this.header = new HeaderComponent(page);

    // Signup form locators
    this.signupHeading = this.page
      .getByRole('heading', { name: /new user signup!/i })
      .or(this.page.locator('.signup-form h2, [data-test="signup-heading"]'));

    this.signupNameInput = this.page
      .locator('input[data-qa="signup-name"]')
      .or(this.page.getByPlaceholder('Name'))
      .or(this.page.locator('form[action*="signup"] input[name="name"]'));

    this.signupEmailInput = this.page
      .locator('input[data-qa="signup-email"]')
      .or(this.page.locator('form[action*="signup"] input[name="email"]'));

    this.signupButton = this.page
      .locator('button[data-qa="signup-button"]')
      .or(this.page.getByRole('button', { name: /signup/i }))
      .or(this.page.locator('form[action*="signup"] button[type="submit"]'));

    // Login form locators
    this.loginHeading = this.page
      .getByRole('heading', { name: /login to your account/i })
      .or(this.page.locator('.login-form h2'));

    this.loginEmailInput = this.page
      .locator('input[data-qa="login-email"]')
      .or(this.page.locator('form[action*="login"] input[name="email"]'));

    this.loginPasswordInput = this.page
      .locator('input[data-qa="login-password"]')
      .or(this.page.locator('form[action*="login"] input[name="password"]'));

    this.loginButton = this.page
      .locator('button[data-qa="login-button"]')
      .or(this.page.getByRole('button', { name: /login/i }))
      .or(this.page.locator('form[action*="login"] button[type="submit"]'));
  }

  async visit(path = '/login'): Promise<void> {
    await test.step(`Navigate to Signup / Login page (${path})`, async () => {
      await TestUtils.suppressAdsAndTrackers(this.page);
      await this.page.goto(path);
      await this.page.waitForLoadState('domcontentloaded');
    });
  }

  async verifyNewUserSignupVisible(): Promise<void> {
    await test.step('Verify "New User Signup!" section is visible', async () => {
      await expect(this.signupHeading).toBeVisible();
      await expect(this.signupNameInput).toBeVisible();
      await expect(this.signupEmailInput).toBeVisible();
      await expect(this.signupButton).toBeVisible();
    });
  }

  async fillSignup(name: string, email: string): Promise<void> {
    await test.step(`Enter name "${name}" and email address "${email}"`, async () => {
      await this.signupNameInput.fill(name);
      await this.signupEmailInput.fill(email);
    });
  }

  async clickSignup(): Promise<void> {
    await test.step('Click "Signup" button', async () => {
      await this.signupButton.click();
      await this.page.waitForLoadState('domcontentloaded');
    });
  }

  async submitSignup(name: string, email: string): Promise<void> {
    await this.fillSignup(name, email);
    await this.clickSignup();
  }
}
