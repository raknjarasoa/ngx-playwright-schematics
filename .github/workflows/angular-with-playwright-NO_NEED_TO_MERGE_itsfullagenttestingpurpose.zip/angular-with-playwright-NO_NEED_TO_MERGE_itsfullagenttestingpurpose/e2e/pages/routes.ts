import { Page, test } from '@playwright/test';

/**
 * Registry of all application URLs and routes.
 * Every URL in the suite must be referenced from here.
 */
export class Routes {
  private readonly page: Page;

  readonly paths = {
    home: '/',
    login: '/login',
    signup: '/signup',
    accountCreated: '/account_created',
    accountDeleted: '/delete_account',
    testCases: '/test_cases',
    products: '/products',
    cart: '/view_cart',
    contactUs: '/contact_us',
  } as const;

  constructor(page: Page) {
    this.page = page;
  }

  async navigateTo(pathKey: keyof Routes['paths']): Promise<void> {
    const path = this.paths[pathKey];
    await test.step(`Navigate to route: ${pathKey} (${path})`, async () => {
      await this.page.goto(path);
      await this.page.waitForLoadState('domcontentloaded');
    });
  }

  async goToHome(): Promise<void> {
    await this.navigateTo('home');
  }

  async goToLogin(): Promise<void> {
    await this.navigateTo('login');
  }

  async goToSignup(): Promise<void> {
    await this.navigateTo('signup');
  }

  async goToAccountCreated(): Promise<void> {
    await this.navigateTo('accountCreated');
  }

  async goToAccountDeleted(): Promise<void> {
    await this.navigateTo('accountDeleted');
  }

  async goToTestCases(): Promise<void> {
    await this.navigateTo('testCases');
  }
}
