import { existsSync, mkdirSync } from 'fs';
import { join } from 'path';

/**
 * Global Setup runs once before all worker processes are spawned.
 * Ensures the required output directories (e2e/auth, artifacts) exist.
 */
export default async function globalSetup(): Promise<void> {
  const rootDir = process.cwd();
  const authDir = join(rootDir, 'e2e', 'auth');
  const artifactsDir = join(rootDir, 'artifacts');

  if (!existsSync(authDir)) {
    mkdirSync(authDir, { recursive: true });
  }

  if (!existsSync(artifactsDir)) {
    mkdirSync(artifactsDir, { recursive: true });
  }
}
