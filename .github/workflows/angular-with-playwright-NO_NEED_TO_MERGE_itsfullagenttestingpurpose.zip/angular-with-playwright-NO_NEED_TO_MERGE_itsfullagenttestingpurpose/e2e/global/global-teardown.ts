/**
 * Global Teardown runs once after all worker processes and tests finish.
 */
export default async function globalTeardown(): Promise<void> {
  // Global teardown logic / telemetry flush if needed
}
