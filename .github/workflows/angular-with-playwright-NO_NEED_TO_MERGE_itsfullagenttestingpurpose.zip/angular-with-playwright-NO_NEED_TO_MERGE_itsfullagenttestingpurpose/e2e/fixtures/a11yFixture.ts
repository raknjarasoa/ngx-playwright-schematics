import { test as base } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

export type A11yFixtures = {
  makeAxeBuilder: () => AxeBuilder;
  checkA11y: (context?: string | string[], options?: { detailedReport?: boolean }) => Promise<void>;
};

/**
 * Accessibility fixture slice for Axe WCAG 2.2 AA testing.
 */
export const a11yFixture = base.extend<A11yFixtures>({
  makeAxeBuilder: async ({ page }, use) => {
    const builder = () =>
      new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa']);
    await use(builder);
  },

  checkA11y: async ({ page }, use, testInfo) => {
    const checkFn = async (context?: string | string[]) => {
      let builder = new AxeBuilder({ page }).withTags([
        'wcag2a',
        'wcag2aa',
        'wcag21a',
        'wcag21aa',
        'wcag22aa',
      ]);

      if (context) {
        builder = builder.include(context);
      }

      const results = await builder.analyze();
      await testInfo.attach('axe-scan-results', {
        body: JSON.stringify(results.violations, null, 2),
        contentType: 'application/json',
      });
    };

    await use(checkFn);
  },
});
