import { test as base } from '@playwright/test';
import { randomBytes } from 'crypto';

export type TelemetryFixtures = {
  traceId: string;
};

/**
 * Telemetry fixture slice injecting W3C traceparent headers for request correlation.
 */
export const telemetryFixture = base.extend<TelemetryFixtures>({
  traceId: async ({ page }, use) => {
    const traceId = randomBytes(16).toString('hex');
    const spanId = randomBytes(8).toString('hex');
    const traceparent = `00-${traceId}-${spanId}-01`;

    await page.setExtraHTTPHeaders({
      traceparent,
    });

    await use(traceId);
  },
});
