import { test as base, Page } from '@playwright/test';
import { TestUtils } from '@helpers/utils';
import { APIClient } from '@helpers/apiClient';

export interface UserRegistrationData {
  title: 'Mr' | 'Mrs';
  name: string;
  email: string;
  password: string;
  dob: {
    day: string;
    month: string;
    year: string;
  };
  newsletter: boolean;
  specialOffers: boolean;
  firstName: string;
  lastName: string;
  company: string;
  address: string;
  address2: string;
  country: string;
  state: string;
  city: string;
  zipcode: string;
  mobileNumber: string;
}

export interface DataFactoryFixtures {
  createdUser: UserRegistrationData;
  mockNetworkFault: (pattern: string | RegExp, status?: number) => Promise<void>;
  mockNetworkLatency: (pattern: string | RegExp, delayMs: number) => Promise<void>;
}

export function generateUserRegistrationData(overrides: Partial<UserRegistrationData> = {}): UserRegistrationData {
  const uniqueEmail = TestUtils.generateUniqueEmail('tester');
  const uniqueName = `Test User ${TestUtils.randomString(4)}`;

  return {
    title: 'Mr',
    name: uniqueName,
    email: uniqueEmail,
    password: 'SecurePassword123!',
    dob: {
      day: '15',
      month: 'June',
      year: '1990',
    },
    newsletter: true,
    specialOffers: true,
    firstName: 'John',
    lastName: 'Doe',
    company: 'Acme International',
    address: '123 Main Street',
    address2: 'Floor 4, Suite 100',
    country: 'United States',
    state: 'New York',
    city: 'New York',
    zipcode: '10001',
    mobileNumber: '+1 555 123 4567',
    ...overrides,
  };
}

export const dataFactoryFixture = base.extend<DataFactoryFixtures>({
  createdUser: async ({}, use) => {
    const testUser = generateUserRegistrationData();
    const apiClient = new APIClient();

    // Hand the user data to the test
    await use(testUser);

    // Teardown / cleanup phase after the test completes
    try {
      // In a real API context, we would call apiClient.deleteUser(testUser.email)
    } finally {
      await apiClient.dispose();
    }
  },

  mockNetworkFault: async ({ page }, use) => {
    const faultFn = async (pattern: string | RegExp, status = 500) => {
      await page.route(pattern, async (route) => {
        await route.fulfill({
          status,
          contentType: 'application/json',
          body: JSON.stringify({ error: 'Injected network fault for resilience testing' }),
        });
      });
    };
    await use(faultFn);
  },

  mockNetworkLatency: async ({ page }, use) => {
    const latencyFn = async (pattern: string | RegExp, delayMs: number) => {
      await page.route(pattern, async (route) => {
        await new Promise((resolve) => setTimeout(resolve, delayMs));
        await route.continue();
      });
    };
    await use(latencyFn);
  },
});
