import { test as base } from '@playwright/test';
import { CONSTANTS } from '@fixtures/constants';

export type CustomFixtures = {
  appTitle: string;
  defaultUserRole: string;
};

/**
 * Custom static test fixtures slice.
 */
export const customFixtures = base.extend<CustomFixtures>({
  appTitle: async ({}, use) => {
    await use(CONSTANTS.APP_TITLE);
  },
  defaultUserRole: async ({}, use) => {
    await use('default');
  },
});
