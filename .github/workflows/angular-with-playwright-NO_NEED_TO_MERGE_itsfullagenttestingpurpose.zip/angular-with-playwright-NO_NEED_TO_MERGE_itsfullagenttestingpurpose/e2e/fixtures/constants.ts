/**
 * Shared constants across the E2E test suite.
 */
export const CONSTANTS = {
  APP_TITLE: 'Automation Exercise',
  DEFAULT_TIMEOUT_MS: 15_000,
  EXTENDED_TIMEOUT_MS: 30_000,
  NAV_LINKS: {
    HOME: 'Home',
    PRODUCTS: 'Products',
    CART: 'Cart',
    SIGNUP_LOGIN: 'Signup / Login',
    LOGOUT: 'Logout',
    DELETE_ACCOUNT: 'Delete Account',
    TEST_CASES: 'Test Cases',
    API_TESTING: 'API Testing',
    VIDEO_TUTORIALS: 'Video Tutorials',
    CONTACT_US: 'Contact us',
  },
  HEADINGS: {
    NEW_USER_SIGNUP: 'New User Signup!',
    LOGIN_TO_ACCOUNT: 'Login to your account',
    ENTER_ACCOUNT_INFORMATION: 'Enter Account Information',
    ADDRESS_INFORMATION: 'Address Information',
    ACCOUNT_CREATED: 'Account Created!',
    ACCOUNT_DELETED: 'Account Deleted!',
  },
} as const;
