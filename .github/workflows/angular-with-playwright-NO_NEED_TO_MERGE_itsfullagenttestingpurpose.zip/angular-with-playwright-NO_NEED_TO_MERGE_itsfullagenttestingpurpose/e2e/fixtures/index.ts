import { mergeTests } from '@playwright/test';
import { pageFixtures } from '@fixtures/pageFixtures';
import { componentFixtures } from '@fixtures/componentFixtures';
import { apiFixtures } from '@fixtures/apiFixtures';
import { dataFactoryFixture } from '@fixtures/dataFactoryFixture';
import { a11yFixture } from '@fixtures/a11yFixture';
import { telemetryFixture } from '@fixtures/telemetryFixture';
import { customFixtures } from '@fixtures/fixtures';

/**
 * Master test extender fusing all fixture slices with mergeTests().
 * All test specs must import { test, expect } from this entrypoint.
 */
export const test = mergeTests(
  pageFixtures,
  componentFixtures,
  apiFixtures,
  dataFactoryFixture,
  a11yFixture,
  telemetryFixture,
  customFixtures
);

export { expect } from '@playwright/test';
