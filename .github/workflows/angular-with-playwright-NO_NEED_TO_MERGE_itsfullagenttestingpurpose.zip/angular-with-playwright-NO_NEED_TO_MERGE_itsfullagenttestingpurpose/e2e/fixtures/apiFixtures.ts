import { test as base } from '@playwright/test';
import { APIClient } from '@helpers/apiClient';

export type APIFixtures = {
  api: APIClient;
};

/**
 * API Fixtures slice.
 * Provides an instance of APIClient bound to the current page context.
 */
export const apiFixtures = base.extend<APIFixtures>({
  api: async ({ page }, use) => {
    const client = new APIClient(page);
    await use(client);
    await client.dispose();
  },
});
