import { test as base } from '@playwright/test';
import { HeaderComponent } from '@components/header.component';
import { ToastComponent } from '@components/toast.component';
import { LoaderComponent } from '@components/loader.component';
import { ModalComponent } from '@components/modal.component';

export type ComponentFixtures = {
  headerComponent: HeaderComponent;
  toastComponent: ToastComponent;
  loaderComponent: LoaderComponent;
  modalComponent: ModalComponent;
};

/**
 * Component Fixtures slice.
 * Contains ONLY global chrome widgets (widgets that can appear anywhere).
 * Screen-specific widgets are owned by their respective Page Objects.
 */
export const componentFixtures = base.extend<ComponentFixtures>({
  headerComponent: async ({ page }, use) => {
    await use(new HeaderComponent(page));
  },
  toastComponent: async ({ page }, use) => {
    await use(new ToastComponent(page));
  },
  loaderComponent: async ({ page }, use) => {
    await use(new LoaderComponent(page));
  },
  modalComponent: async ({ page }, use) => {
    await use(new ModalComponent(page));
  },
});
