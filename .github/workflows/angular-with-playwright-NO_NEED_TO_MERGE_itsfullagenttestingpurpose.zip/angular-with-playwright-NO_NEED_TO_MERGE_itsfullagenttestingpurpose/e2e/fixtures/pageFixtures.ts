import { test as base } from '@playwright/test';
import { Routes } from '@pages/routes';
import { HomePage } from '@pages/homePage';
import { LoginSignupPage } from '@pages/loginSignupPage';
import { SignupAccountPage } from '@pages/signupAccountPage';
import { AccountCreatedPage } from '@pages/accountCreatedPage';
import { AccountDeletedPage } from '@pages/accountDeletedPage';

export type PageFixtures = {
  routes: Routes;
  homePage: HomePage;
  loginSignupPage: LoginSignupPage;
  signupAccountPage: SignupAccountPage;
  accountCreatedPage: AccountCreatedPage;
  accountDeletedPage: AccountDeletedPage;
};

/**
 * Page Fixtures slice.
 * Contains one fixture per application route/screen.
 */
export const pageFixtures = base.extend<PageFixtures>({
  routes: async ({ page }, use) => {
    await use(new Routes(page));
  },
  homePage: async ({ page }, use) => {
    await use(new HomePage(page));
  },
  loginSignupPage: async ({ page }, use) => {
    await use(new LoginSignupPage(page));
  },
  signupAccountPage: async ({ page }, use) => {
    await use(new SignupAccountPage(page));
  },
  accountCreatedPage: async ({ page }, use) => {
    await use(new AccountCreatedPage(page));
  },
  accountDeletedPage: async ({ page }, use) => {
    await use(new AccountDeletedPage(page));
  },
});
