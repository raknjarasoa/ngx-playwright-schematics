export interface UserCredentials {
  email: string;
  password: string;
  name?: string;
}

export type UserRole = 'default' | 'admin' | 'guest';

/**
 * Manages test persona credentials fed from environment variables.
 * Never hardcode real credentials in test code.
 */
export class CredsManager {
  private static readonly accounts: Record<UserRole, () => UserCredentials> = {
    default: () => ({
      email: process.env['E2E_USER_EMAIL'] || 'default_user@example.com',
      password: process.env['E2E_USER_PASSWORD'] || 'Password123!',
      name: 'Default User',
    }),
    admin: () => ({
      email:
        process.env['E2E_ADMIN_EMAIL'] ||
        process.env['E2E_USER_EMAIL'] ||
        'admin_user@example.com',
      password:
        process.env['E2E_ADMIN_PASSWORD'] ||
        process.env['E2E_USER_PASSWORD'] ||
        'Password123!',
      name: 'Admin User',
    }),
    guest: () => ({
      email: 'guest_user@example.com',
      password: 'GuestPassword123!',
      name: 'Guest User',
    }),
  };

  static getCredentials(role: UserRole = 'default'): UserCredentials {
    const getter = this.accounts[role];
    if (!getter) {
      throw new Error(`Unknown user role "${role}". Supported roles: ${Object.keys(this.accounts).join(', ')}`);
    }
    return getter();
  }
}
