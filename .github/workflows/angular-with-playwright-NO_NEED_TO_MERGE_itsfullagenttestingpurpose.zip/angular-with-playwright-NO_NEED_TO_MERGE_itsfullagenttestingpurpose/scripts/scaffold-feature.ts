import { existsSync, readFileSync, writeFileSync } from 'fs';
import { join } from 'path';

interface NamingConventions {
  raw: string;
  camel: string;
  pascal: string;
  kebab: string;
  human: string;
}

function toNamingConventions(input: string): NamingConventions {
  const sanitized = input.trim().replace(/[^a-zA-Z0-9_-]/g, '');
  // Split on separators and on camel/Pascal boundaries, keeping acronyms whole:
  // "userProfile" -> [user, Profile], "ABCWidget" -> [ABC, Widget], "APIKeys" -> [API, Keys].
  const parts = sanitized
    .split(/[-_]+|(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])/)
    .filter(Boolean)
    .map((p) => p.toLowerCase());

  const capitalize = (p: string) => p.charAt(0).toUpperCase() + p.slice(1);

  const camel = parts.map((p, idx) => (idx === 0 ? p : capitalize(p))).join('');
  const pascal = parts.map(capitalize).join('');
  const kebab = parts.join('-');
  const human = parts.map(capitalize).join(' ');

  return { raw: input, camel, pascal, kebab, human };
}

/**
 * TypeScript identifiers cannot start with a digit. Without this guard a name like "2fa-setup"
 * generates `2faSetup: async (...)` and every generated file fails to compile.
 */
function assertUsableIdentifier(names: NamingConventions): void {
  const identifier = /^[A-Za-z_$][A-Za-z0-9_$]*$/;
  if (!identifier.test(names.camel) || !identifier.test(names.pascal)) {
    throw new Error(
      `Feature name "${names.raw}" produces the invalid TypeScript identifier "${names.camel}". ` +
        'Start the name with a letter — e.g. "twoFactorSetup" rather than "2fa-setup".'
    );
  }
}

export class FeatureTestScaffolder {
  private rootDir = process.cwd();

  /**
   * Applies a regex replacement and fails loudly when the anchor is missing.
   *
   * `String.replace` returns the input unchanged when nothing matches, so an anchor that drifted
   * (a reformat, a renamed method) used to write the file back identical while the caller still
   * logged success. Throwing here turns that silent no-op into an actionable error.
   */
  private replaceOrThrow(
    content: string,
    pattern: RegExp,
    replacement: string,
    file: string,
    anchor: string,
  ): string {
    const next = content.replace(pattern, replacement);
    if (next === content) {
      throw new Error(
        `Could not update ${file}: expected to find ${anchor}.\n` +
          '   The file may have been reformatted or renamed. Apply the change by hand, or update ' +
          'the anchor in scripts/scaffold-feature.ts.',
      );
    }
    return next;
  }

  scaffold(featureName: string, overwrite = false, dialog = true): void {
    if (!featureName) {
      console.error('❌ Error: Please specify a feature name.');
      console.log('👉 Usage: npm run e2e:scaffold <feature-name>');
      console.log('   Example: npm run e2e:scaffold userProfile');
      process.exit(1);
    }

    const names = toNamingConventions(featureName);
    assertUsableIdentifier(names);
    console.log(`\n🎭 Scaffolding Playwright E2E Feature: "${names.human}" (${names.kebab})...\n`);

    this.scaffoldComponent(names, overwrite, dialog);
    this.scaffoldPageObject(names, overwrite);
    this.updateRoutes(names);
    this.updatePageFixtures(names);
    this.scaffoldSpec(names, overwrite, dialog);

    console.log('\n✨ Feature test slice scaffolded successfully!');
    console.log(`\n🚀 Run your new test with:\n   npx playwright test e2e/specs/${names.kebab}.spec.ts --ui\n`);
  }

  private scaffoldComponent(names: NamingConventions, overwrite: boolean, dialog: boolean): void {
    const componentPath = join(this.rootDir, 'e2e', 'components', `${names.camel}.component.ts`);
    if (existsSync(componentPath) && !overwrite) {
      console.log(`ℹ️  Component already exists: e2e/components/${names.camel}.component.ts`);
      return;
    }

    const header = dialog
      ? `import { Locator, Page, expect, test } from '@playwright/test';
import { ModalComponent } from '@components/modal.component';

/**
 * Component Object for the ${names.human} dialog.
 *
 * Dialog chrome (root, title, close control, open/closed state) is delegated to a composed
 * {@link ModalComponent}, so those selectors live in exactly one place. This class adds only the
 * ${names.human}-specific controls.
 */
export class ${names.pascal}Component {
  readonly modal: ModalComponent;
  readonly root: Locator;`
      : `import { Locator, Page, expect, test } from '@playwright/test';

/**
 * Component Object for the ${names.human} widget (not a dialog — standalone root).
 */
export class ${names.pascal}Component {
  readonly root: Locator;`;

    const rootInit = dialog
      ? `    const root =
      rootLocator ||
      page
        .getByRole('dialog', { name: /${names.human}/i })
        .or(page.locator('[data-test="${names.kebab}-widget"], .${names.kebab}-widget'));

    // Compose the generic modal shell for dialog chrome (title, backdrop, close button).
    this.modal = new ModalComponent(page, root);
    this.root = this.modal.root;`
      : `    this.root =
      rootLocator ||
      page
        .getByRole('region', { name: /${names.human}/i })
        .or(page.locator('[data-test="${names.kebab}-widget"], .${names.kebab}-widget'));`;

    const closeMethod = dialog
      ? `
  async close(): Promise<void> {
    await test.step(\`Close ${names.human} without applying\`, async () => {
      await this.modal.close();
    });
  }
`
      : '';

    const content = `${header}
  readonly searchInput: Locator;
  readonly applyButton: Locator;
  readonly resetButton: Locator;

  constructor(page: Page, rootLocator?: Locator) {
${rootInit}

    this.searchInput = this.root
      .getByRole('searchbox')
      .or(this.root.getByPlaceholder(/search|rechercher/i))
      .or(this.root.locator('[data-test="${names.kebab}-search"]'));

    this.applyButton = this.root
      .getByRole('button', { name: /apply|save|valider|appliquer/i })
      .or(this.root.locator('[data-test="apply-${names.kebab}"]'));

    this.resetButton = this.root
      .getByRole('button', { name: /reset|cancel|annuler/i })
      .or(this.root.locator('[data-test="reset-${names.kebab}"]'));
  }

  async expectVisible(): Promise<void> {
    await test.step('Verify ${names.human} is visible', async () => {
      await expect(this.root).toBeVisible();
    });
  }

  async expectHidden(): Promise<void> {
    await test.step('Verify ${names.human} is hidden', async () => {
      await expect(this.root).toBeHidden();
    });
  }

  async search(query: string): Promise<void> {
    await test.step(\`Search for "\${query}" in ${names.human}\`, async () => {
      await this.searchInput.fill(query);
    });
  }

  async apply(): Promise<void> {
    await test.step(\`Apply ${names.human} configuration\`, async () => {
      await this.applyButton.click();${dialog ? '\n      await this.expectHidden();' : ''}
    });
  }

  async reset(): Promise<void> {
    await test.step(\`Reset ${names.human} configuration\`, async () => {
      await this.resetButton.click();
    });
  }
${closeMethod}}
`;

    writeFileSync(componentPath, content);
    console.log(`✅ Created Component: e2e/components/${names.camel}.component.ts`);
  }

  private scaffoldPageObject(names: NamingConventions, overwrite: boolean): void {
    const pagePath = join(this.rootDir, 'e2e', 'pages', `${names.camel}Page.ts`);
    if (existsSync(pagePath) && !overwrite) {
      console.log(`ℹ️  Page Object already exists: e2e/pages/${names.camel}Page.ts`);
      return;
    }

    const content = `import { Locator, Page, expect, test } from '@playwright/test';
import { Routes } from '@pages/routes';
import { ${names.pascal}Component } from '@components/${names.camel}.component';

/**
 * Page Object for ${names.human} screen (/${names.kebab}).
 */
export class ${names.pascal}Page {
  private readonly page: Page;
  readonly routes: Routes;
  readonly openWidgetButton: Locator;
  readonly dataTable: Locator;
  readonly ${names.camel}: ${names.pascal}Component; // Page OWNS the embedded widget

  constructor(page: Page) {
    this.page = page;
    this.routes = new Routes(page);
    this.openWidgetButton = this.page
      .getByRole('button', { name: /${names.human}|configure/i })
      .or(this.page.locator('[data-test="open-${names.kebab}-btn"]'));
    this.dataTable = this.page
      .getByRole('table')
      .or(this.page.locator('table, [data-test="data-table"]'));
    this.${names.camel} = new ${names.pascal}Component(page);
  }

  async visit(path = '/${names.kebab}'): Promise<void> {
    await test.step(\`Navigate to ${names.human} page: \${path}\`, async () => {
      await this.page.goto(path);
      await this.page.waitForLoadState('domcontentloaded');
    });
  }

  async open${names.pascal}(): Promise<void> {
    await test.step(\`Open ${names.human} configuration\`, async () => {
      await this.openWidgetButton.click();
      await this.${names.camel}.expectVisible();
    });
  }

  async verifyTableVisible(): Promise<void> {
    await test.step('Verify results data table is visible', async () => {
      await expect(this.dataTable).toBeVisible();
    });
  }
}
`;

    writeFileSync(pagePath, content);
    console.log(`✅ Created Page Object: e2e/pages/${names.camel}Page.ts`);
  }

  private updateRoutes(names: NamingConventions): void {
    const routesPath = join(this.rootDir, 'e2e', 'pages', 'routes.ts');
    if (!existsSync(routesPath)) return;

    const original = readFileSync(routesPath, 'utf-8');
    if (new RegExp(`^\\s*${names.camel}:`, 'm').test(original)) {
      console.log(`ℹ️  Route '${names.camel}' already registered in e2e/pages/routes.ts`);
      return;
    }

    // Insert path into paths object
    let content = this.replaceOrThrow(
      original,
      /(readonly paths = \{[\s\S]*?)(\n\s*\};)/,
      `$1\n    ${names.camel}: '/${names.kebab}',$2`,
      'e2e/pages/routes.ts',
      'the `readonly paths = { … };` object',
    );

    // Insert helper navigation method
    const navMethod = `  async goTo${names.pascal}(): Promise<void> {\n    await this.navigateTo('${names.camel}');\n  }\n`;
    content = this.replaceOrThrow(
      content,
      /(navigateTo\(pathKey: keyof Routes\['paths'\]\): Promise<void> \{[\s\S]*?\n  \})/,
      `$1\n\n${navMethod}`,
      'e2e/pages/routes.ts',
      "the `navigateTo(pathKey: keyof Routes['paths'])` method",
    );

    writeFileSync(routesPath, content);
    console.log(`✅ Updated Routes: e2e/pages/routes.ts (added '/${names.kebab}')`);
  }

  private updatePageFixtures(names: NamingConventions): void {
    const fixturesPath = join(this.rootDir, 'e2e', 'fixtures', 'pageFixtures.ts');
    if (!existsSync(fixturesPath)) return;

    const original = readFileSync(fixturesPath, 'utf-8');
    if (new RegExp(`^\\s*${names.camel}Page:`, 'm').test(original)) {
      console.log(`ℹ️  Fixture '${names.camel}Page' already registered in e2e/fixtures/pageFixtures.ts`);
      return;
    }

    // Do the two anchored replacements FIRST. If either anchor is gone we throw before writing
    // anything, so the file is never left with an orphaned import and no matching fixture —
    // a state that neither `eslint e2e` nor `tsc --noEmit` would catch.
    let content = this.replaceOrThrow(
      original,
      /(export type PageFixtures = \{[\s\S]*?)(\n\};)/,
      `$1\n  ${names.camel}Page: ${names.pascal}Page;$2`,
      'e2e/fixtures/pageFixtures.ts',
      'the `export type PageFixtures = { … };` block',
    );

    content = this.replaceOrThrow(
      content,
      /(export const pageFixtures = base\.extend<PageFixtures>\(\{[\s\S]*?)(\n\}\);)/,
      `$1\n  ${names.camel}Page: async ({ page }, use) => await use(new ${names.pascal}Page(page)),$2`,
      'e2e/fixtures/pageFixtures.ts',
      'the `base.extend<PageFixtures>({ … })` block',
    );

    // Only now add the import, after the last existing @pages/* import rather than above everything.
    content = this.replaceOrThrow(
      content,
      /(import \{[^}]*\} from '@pages\/[^']+';\n)(?![\s\S]*import \{[^}]*\} from '@pages\/)/,
      `$1import { ${names.pascal}Page } from '@pages/${names.camel}Page';\n`,
      'e2e/fixtures/pageFixtures.ts',
      "an existing `@pages/…` import to anchor the new one to",
    );

    writeFileSync(fixturesPath, content);
    console.log(`✅ Updated Fixtures: e2e/fixtures/pageFixtures.ts (injected '${names.camel}Page')`);
  }

  private scaffoldSpec(names: NamingConventions, overwrite: boolean, dialog: boolean): void {
    const specPath = join(this.rootDir, 'e2e', 'specs', `${names.kebab}.spec.ts`);
    if (existsSync(specPath) && !overwrite) {
      console.log(`ℹ️  Spec file already exists: e2e/specs/${names.kebab}.spec.ts`);
      return;
    }

    const content = `import { test, expect } from '@fixtures/index';

test.describe('${names.human} Feature Functional Specification', () => {
  test.beforeEach(async ({ ${names.camel}Page }) => {
    await ${names.camel}Page.visit();
  });

  test(
    'should open ${names.human} widget, perform search, and apply changes',
    {
      tag: ['@smoke', '@regression', '@ui'],
    },
    async ({ ${names.camel}Page, toastComponent }) => {
      // 1. Open the widget via the page
      await ${names.camel}Page.open${names.pascal}();

      // 2. Search or configure
      await ${names.camel}Page.${names.camel}.search('Test Query');

      // 3. Apply changes and verify modal closes
      await ${names.camel}Page.${names.camel}.apply();

      // 4. Verify page updates
      await ${names.camel}Page.verifyTableVisible();
      await toastComponent.verifyNoFatalErrors();
    }
  );

  test(
    'should ${dialog ? `dismiss ${names.human} without applying changes` : `reset ${names.human} back to its initial state`}',
    {
      tag: ['@regression', '@ui'],
    },
    async ({ ${names.camel}Page }) => {
      await ${names.camel}Page.open${names.pascal}();
${
  dialog
    ? `      await ${names.camel}Page.${names.camel}.close();
      await ${names.camel}Page.${names.camel}.expectHidden();`
    : `      await ${names.camel}Page.${names.camel}.reset();
      await ${names.camel}Page.${names.camel}.expectVisible();`
}
    }
  );
});
`;

    writeFileSync(specPath, content);
    console.log(`✅ Created Test Spec: e2e/specs/${names.kebab}.spec.ts`);
  }
}

const args = process.argv.slice(2);
const featureArg = args.find((a) => !a.startsWith('-'));
const overwriteFlag = args.includes('--overwrite') || args.includes('-o');
// Non-dialog widgets (panels, drawers, toolbars, grids) get a standalone component object
// instead of one composing ModalComponent.
const dialogFlag = !(args.includes('--no-dialog') || args.includes('--panel'));

try {
  new FeatureTestScaffolder().scaffold(featureArg ?? '', overwriteFlag, dialogFlag);
} catch (err) {
  console.error(`\n❌ Scaffolding aborted: ${(err as Error).message}\n`);
  process.exit(1);
}
